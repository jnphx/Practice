﻿// Budget Calculations
//$(document).load(function () {
//    $(".datetimepicker100").on('dp.change', function () {
//        event.stoppropagation();
//    });
//})

$(document).ready(function () {
    calculateTaxTotal();
    calculateGrandTotalForLineItems();
});


//$(document).ready(function () {
//    var costUnitCheck = $('.unit').val();
//    if (costUnitCheck == "")
//    {
//        $('.unit').val(0);
//        $('.ext').val(0);
//        $('.shipping').val(0);
//        $('.taxAmount').val(0);
//    }
//        var toMatch;
//        toMatch = $('.qty').val();

//        if(toMatch === 0)
//        {
//            tempVar = 0;
//            //alert(toMatch);
//            $('.totalCost').val(tempVar.toFixed(2));
//            $('.totalTax').val(tempVar.toFixed(2));
//            //$('.lineItemGrandTotal').val(tempVar.toFixed(2));
            
//        }
//        else {
//            calculateTaxTotal();
//            calculateGrandTotalForLineItems();
//        }
        
//});

//$(function () {
//    $(".shipping").blur(function () {
//        //var valorinicial = document.getElementById('valorinicial');
//        var fee = document.getElementById('fee');
//        //var value = valorinicial.value();
//        var number = parseFloat(value) * 5 / 100;
//        //fee.value = number;
//        fee.val(number);
//        calculateTaxTotal();
//        calculateGrandTotalForLineItems();
//    });
//});

//$(function () {
//    $('.unit').focusout(function () {
//        calculateTaxTotal();
//        calculateGrandTotalForLineItems();
//    });
//});

function calculateGrandTotalForLineItems() {
    var shippingTotal = $('#theRequest_SHIPPING_CHARGES').val();
    var taxTotal = $('.totalTax').val();
    var estimatedResources = 0.00;

    var sum = 0.0;
    $('.ext').each(function () {
        sum += parseFloat(this.value.replace(/,/g, ''), 10);
    });

    if (!isNaN(sum)) {
        estimatedResources = sum;
    }
    
    if(shippingTotal.indexOf(',') || taxTotal.indexOf(','))
    {
        var shippingCharges = parseFloat(shippingTotal.replace(/,/g, ''), 10); // convert it to a float 
        var taxCharges = parseFloat(taxTotal.replace(/,/g, ''), 10); // convert it to a float
    }
    else {
        shippingCharges = shippingTotal;
        taxCharges = taxTotal;
    }
   
    var result = estimatedResources + shippingCharges + taxCharges;

    //alert("result: " + result);
    //alert("result: " + result + " shipping charges: " + shippingCharges + " tax charges:" + taxCharges + " sum: " + sum);
    if (!isNaN(shippingCharges) && !isNaN(taxCharges)) {
        $('.totalCost').val(parseFloat(estimatedResources, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
        $('.totalTax').val(parseFloat(taxCharges, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
        $('.lineItemGrandTotal').val(parseFloat(result, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
    }
    else {
        $('.totalCost').val(parseFloat(0.00, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));        
        $('.totalTax').val(parseFloat(taxCharges, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
        $('.lineItemGrandTotal').val(parseFloat(0, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
    }
};

//STAFFING CALCULATIONS

//FTE Calc
function calculateFTE(parent) { 
    var hpd = parseFloat(parent.find('#theStaffingRequest_HOURS_PER_DAY').val()); // get value of field     
    var dpw = parseFloat(parent.find('#theStaffingRequest_DAYS_PER_WEEK').val()); // convert it to a float    
    var value = (hpd * dpw) / 40
    if (!isNaN(hpd) && !isNaN(dpw)) { //if there's a value do the calculation
        parent.find('#theStaffingRequest_FTE').val(parseFloat(value, 10).toFixed(3).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString()); 
    }
    else {
        parent.find('#theStaffingRequest_FTE').val(0).toFixed(3);
    }

};

//Actual Salary

function calculateActualSalary(parent) {

    var fte = parseFloat(parent.find('#theStaffingRequest_FTE').val()); // get value of field    
    var annSal = parseFloat(parent.find('#thePosition_AVG_SALARY').val().replace(/,/g, ''), 10); // convert it to a float    
    var value = fte * annSal;
    if (!isNaN(fte) && !isNaN(annSal)) { //if there's a value do the calculation
        parent.find('#theStaffingRequest_ACTUAL_SALARY').val(parseFloat(value, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());
        //        alert(fte * annSal);
    }
    else {
        parent.find('#theStaffingRequest_ACTUAL_SALARY').val((0.00).toFixed(2));
    }

};

//Benefits

function calculateBenefits(parent) {
    var requestId = $("#theRequest_REQUEST_ID").val();
    var actSal = parseFloat(parent.find('#theStaffingRequest_ADJ_ACTUAL_SALARY').val().replace(/,/g, ''), 10); // convert it to a float
    //var value = actSal * .2013;

    $.ajax({
        //dataType: "json",
        url: '../../Requests/GetBenefitsCalc',
        dataType: 'json',
        data: { requestId: requestId, actSal: actSal },
        success: function (data) {
            parent.find('#theStaffingRequest_BENEFITS').val(parseFloat(data, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString()); //parseFloat(data, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString()  
            Calculations(parent);    
        },
        error: function (xhr, ajaxOptions, error) {
            alert('Error has occured.  Please contact application administrators and reference the following: CalculateBenefits ' + xhr.status + '.  Please verify the fiscal year is active.');
        }
    });

//    if (!isNaN(actSal)) { //if there's a value do the calculation
//        parent.find('#theStaffingRequest_BENEFITS').val(value.toFixed(2));
//    }
//    else {
//        parent.find('#theStaffingRequest_BENEFITS').val((0.00).toFixed(2));
//    }

};

//Grand Total

function calculateGrandTotal(parent) {
    var benefits = parseFloat(parent.find('#theStaffingRequest_BENEFITS').val().replace(/,/g, ''), 10);
    var actSal = parseFloat(parent.find('#theStaffingRequest_ADJ_ACTUAL_SALARY').val().replace(/,/g, ''), 10);
    var insurance = parseFloat(parent.find('#theStaffingRequest_INSURANCE').val().replace(/,/g, ''), 10);
    var sum = actSal + benefits + insurance;
    if (!isNaN(benefits) && !isNaN(actSal) && !isNaN(insurance)) { //if there's a value do the calculation
        parent.find('#theStaffingRequest_GRAND_TOTAL').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());
    }
    else {
        parent.find('#theStaffingRequest_GRAND_TOTAL').val((0.00).toFixed(2));
    }
};

//Total Estimated Salaries

function calculateTotalSalaries() {
    var sum = 0.0; 
    $('.adjSalary').each(function () {
        sum += parseFloat(this.value.replace(/,/g, ''), 10);
    });

    if (!isNaN(sum)) {
        $('#theRequest_ESTIMATED_SALARIES').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());
    }
    else {
        $('#theRequest_ESTIMATED_SALARIES').val((0.00).toFixed(2));
    }

};

//Total Estimated Benefits

function calculateTotalBenefits() {
    var sum = 0.0;
    $('.benefits').each(function () {
        sum += parseFloat(this.value.replace(/,/g, ''), 10);
        //        sum += parseFloat(this.value); parseInt(str.replace(/,/g, ''), 10)
    });

    if (!isNaN(sum)) {
        $('#theRequest_ESTIMATED_BENEFITS').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString()); 
    }
    else {
        $('#theRequest_ESTIMATED_BENEFITS').val((0.00).toFixed(2));
    }

};

//Total Estimated Insurance

function calculateTotalInsurance() {
    var sum = 0.0;
    $('.insCalc').each(function () {
        sum += parseFloat(this.value.replace(/,/g, ''), 10);
    });

    if (!isNaN(sum)) {
        $('#theRequest_ESTIMATED_INSURANCE').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());
    }
    else {
        $('#theRequest_ESTIMATED_INSURANCE').val((0.00).toFixed(2));
    }

};

//Total Estimated Personnel Cost

function calculateTotal() {

    var totalSal = parseFloat($('#theRequest_ESTIMATED_SALARIES').val().replace(/,/g, ''), 10);
    var totalBen = parseFloat($('#theRequest_ESTIMATED_BENEFITS').val().replace(/,/g, ''), 10);
    var totalIns = parseFloat($('#theRequest_ESTIMATED_INSURANCE').val().replace(/,/g, ''), 10);
    var sum = totalSal + totalBen + totalIns;
    if (!isNaN(totalSal) && !isNaN(totalBen) && !isNaN(totalIns)) { //if there's a value do the calculation
        $('#theRequest_ESTIMATED_PERSONNEL_COST').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());
    }
    else {
        $('#theRequest_ESTIMATED_PERSONNEL_COST').val((0.00).toFixed(2));
    }
};

//Populating Calculations

function Calculations(parent) {
       
    //calculateFTE(parent); -7/22/21 - taking out calculation since field is editable
    calculateActualSalary(parent);
    //calculateBenefits(parent);
    calculateGrandTotal(parent);
    calculateTotalSalaries();
    calculateTotalInsurance();
    calculateTotalBenefits();    
    calculateTotal();
}


$(document).on('click', "#theStaffingRequest_POSITION_ID", function () {
    //var parent = $(this).parent().parent();

    var parent = $(this).parents(".positionContainer");
    var positionId = $(this).val();

    if (positionId > 0) {
        GetPositionSalary(positionId, parent)
    }
    //    $.ajax({
    //        //dataType: "json",
    //        url: '../../Requests/GetPositionSalary',
    //        dataType: 'json',
    //        data: { positionId: positionId },
    //        success: function (data) {
    //            parent.find('#thePosition_AVG_SALARY').val(parseFloat(data, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());
    //            Calculations(parent);
    //            GetSalaryAdj(parent);
    //        },
    //        error: function (xhr, ajaxOptions, error) {
    //            alert('Error has occured.  Please contact application administrators and reference the following: GetPositionSalary ' + xhr.status);
    //        }
    //    });
});

function GetPositionSalary(positionId, parent) {
    $.ajax({
        //dataType: "json",
        url: '../../Requests/GetPositionSalary',
        dataType: 'json',
        data: { positionId: positionId },
        success: function (data) {
            parent.find('#thePosition_AVG_SALARY').val(parseFloat(data, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());
            Calculations(parent);
            GetSalaryAdj(parent);
        },
        error: function (xhr, ajaxOptions, error) {
            alert('Error has occured.  Please contact application administrators and reference the following: GetPositionSalary ' + xhr.status);
        }
    });
}

$(document).on('click', ".staffType", function () {
    //this calculates values automatically   
    var parent = $(this).parent('.positionContainer');
    var positionId = $(this).parent().prev().find("#theStaffingRequest_POSITION_ID").val();

    if (positionId > 0) {
        GetPositionSalary(positionId, parent);
    }
});

$(document).on('change', ".day", function () {
    //this calculates values automatically    

    var parent = $(this).parents(".positionContainer");
    Calculations(parent);
    GetSalaryAdj(parent);
});

$(document).on('change', ".hour", function () {
    //this calculates values automatically  
    var hours = $(this).val();
    if (hours.length == 0) {
        $(this).val("0.000");
    }

    var parent = $(this).parents(".positionContainer");
    
    Calculations(parent);
    GetSalaryAdj(parent);
});

// -7/22/21 - Added change to recalc if FTE changes
$(document).on('change', ".fte", function () {
    //this calculates values automatically  
    var parent = $(this).parents(".positionContainer");
    Calculations(parent);
    GetSalaryAdj(parent);
});

$(document).on('dp.change', ".datetimepicker100", function () {
    //this calculates values automatically    
    var parent = $(this).parents(".positionContainer");
    var origDate = $(this).find("effectiveDate").data("effdate");
    var dt = new Date();
    var month = dt.getMonth() + 1;
    var day = dt.getDate();
    var today = dt.getFullYear() + '/' + (month < 10 ? '0' : '') + month + '/' + (day < 10 ? '0' : '') + day;
    var todayToDisplay = (month < 10 ? '0' : '') + month + '/' + (day < 10 ? '0' : '') + day + "/" + dt.getFullYear();
    var timestamp = $(this).children().val();
    var comp = timestamp.split('/');
    var y = parseInt(comp[2], 10);
    var m = parseInt(comp[0], 10);
    var d = parseInt(comp[1], 10);
    var date = new Date(y, m - 1, d);
    var dateEntered = date.getFullYear() + '/' + (m < 10 ? '0' : '') + m + '/' + (d < 10 ? '0' : '') + d;

    if (date.getFullYear() == y && date.getMonth() + 1 == m && date.getDate() == d) {
        Calculations(parent);
        GetSalaryAdj(parent);
    }
});

$(document).on('change', ".salary", function () {
    var parent = $(this).parents('.positionContainer');
    GetSalaryAdj(parent);
});

function GetSalaryAdj(parent) {
    var effectiveDate = parent.find(".effectiveDate").val();
    var actualSalary = parseFloat(parent.find(".actSalary").val().replace(/,/g, ''), 10);
    var positionId = parent.find(".posId").val();    

    if (effectiveDate.length != 0 && actualSalary.length != 0 && positionId != 0) {
        $.ajax({
            //dataType: "json",
            url: '../../Requests/GetAdjustedSalary',
            dataType: 'json',
            data: { positionId: positionId, effectiveDate: effectiveDate, actualSalary: actualSalary },
            success: function (data) {
                parent.find('.adjSalary').val(parseFloat(data, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());
                GetInsuranceCalc(parent);
                calculateBenefits(parent);
            },
            error: function (xhr, ajaxOptions, error) {
                alert('Error has occured.  Please contact application administrators and reference the following: GetAdjustedSalary ' + xhr.status);
            }
        });
    }
}

function GetInsuranceCalc(parent) {
    var effectiveDate = parent.find(".effectiveDate").val();
    var adjSalary = parseFloat(parent.find(".actSalary").val().replace(/,/g, ''), 10);
    var positionId = parent.find(".posId").val();
    var fte = parent.find(".fte").val();
    var requestId = $("#theRequest_REQUEST_ID").val();

    if (effectiveDate.length != 0 && adjSalary.length != 0 && positionId != 0) {
        $.ajax({
            //dataType: "json",
            url: '../../Requests/GetInsuranceCalc',
            dataType: 'json',
            data: { requestId: requestId, positionId: positionId, effectiveDate: effectiveDate, adjSalary: adjSalary, fte: fte },
            success: function (data) {
                parent.find('.insCalc').val(parseFloat(data, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());                
                Calculations(parent);
            },
            error: function (xhr, ajaxOptions, error) {
                alert('Error has occured.  Please contact application administrators and reference the following: GetAdjustedSalary ' + xhr.status);
            }
        });
    }
}

//Line Item Calculations
$(document).on('change', ".tax", function () {
    //this calculates values automatically    
    var parent = $(this).parent().parent();
    LineItemCalculations(parent);
});

$(document).on('change', ".qty", function () {
    //this calculates values automatically    
    var parent = $(this).parent().parent();
    LineItemCalculations(parent);
});

$(document).on('change', ".unit", function () {
    //this calculates values automatically    
    var parent = $(this).parent().parent();
    LineItemCalculations(parent);
});

$(document).on('change', ".ext", function () {
    //this calculates values automatically    
    var parent = $(this).parent().parent();
    LineItemCalculations(parent);
});

$(document).on('change', ".shipping", function () {
    //this calculates values automatically    
    var parent = $(this).parent().parent();
    LineItemCalculations(parent);
});

function LineItemCalculations(parent) {
    calculateLineItemCost(parent);
}

function calculateLineItemCost(parent) {
    var qty = parseFloat(parent.find('#theLineItem_QUANTITY').val().replace(/,/g, ''), 10); // get value of field  
    var itemCost = parseFloat(parent.find('#theLineItem_COST').val().replace(/,/g, ''), 10); //parseFloat(parent.find('#theLineItem_COST').val()); // convert it to a float    

    if (!isNaN(qty) && !isNaN(itemCost)) { //if there's a value do the calculation
        var cost = qty * itemCost;
        parent.find('#theLineItem_EXT_COST').val(parseFloat(cost, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));        
    }    
    else {
        parent.find('#theLineItem_EXT_COST').val(parseFloat(0.00, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));        
    }

    calculateTaxes(parent, cost);
};

function calculateLineItemSubTotal(parent) {
    var extCost = parseFloat(parent.find('#theLineItem_EXT_COST').val().replace(/,/g, ''), 10);
    //$('.totalCost').val(parseFloat(extCost, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
    var shipping = parseFloat(parent.find('#theLineItem_SHIPPING').val().replace(/,/g, ''), 10);
    if (isNaN(shipping)) {
        shipping = parseFloat(0.00.toFixed(2));
    }

    var tax = parseFloat(parent.find('#theLineItem_TAX_AMOUNT').val().replace(/,/g, ''), 10); 
    var sum = extCost + shipping + tax;

    if (!isNaN(extCost) && !isNaN(shipping) && !isNaN(tax)) { //if there's a value do the calculation
        parent.find('#theLineItem_TOTAL').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
        $('input.totalCost').val(parseFloat(extCost, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
        $('input.totalTax').val(parseFloat(tax, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
        $('input.lineItemGrandTotal').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
    }
    else {
        parent.find('#theLineItem_TOTAL').val(parseFloat(0.00, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
        $('input.totalCost').val(parseFloat(extCost, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
        $('input.totalTax').val(parseFloat(tax, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
        $('input.lineItemGrandTotal').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
    }
};

function calculateTaxTotal(parent) {
    var sum = 0.0;
    $('.taxAmount').each(function () {
        var taxAmount = parseFloat($(this).val().replace(/,/g, ''), 10)
        sum += taxAmount;
    });

    if (!isNaN(sum)) {
        $('input.totalTax').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
    }
    else {
        $('input.totalTax').val(parseFloat(0.00, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
    }

    //alert(sum);

};

function calculateShippingTotal() {
    var sum = 0.0;
    $('.shipping').each(function () {
        sum += parseFloat(this.value.replace(/,/g, ''), 10);
    });

    if (!isNaN(sum)) {
        $('#theRequest_SHIPPING_CHARGES').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
    }
    else {
        $('#theRequest_SHIPPING_CHARGES').val(parseFloat(0.00, 10).toFixed(2).replace(/,/g, ''), 10);
    }
};

function calculateTotalLineItem() {
    var sum = 0.0;
    $('.lineTotal').each(function () {        
        sum += parseFloat(this.value.replace(/,/g, ''), 10);
    });

    if (!isNaN(sum)) {
        $('#theRequest_ESTIMATED_RESOURCES').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
        $('.totalCost').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
    }
    else {
        $('#theRequest_ESTIMATED_RESOURCES').val(parseFloat(0.00, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
        $('.totalCost').val(parseFloat(0.00, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
    }

    calculateLineItemStaffingTotals();
};

function calculateLineItemStaffingTotals() {
    var sum = 0.0;
    var estimatedResources = $('#theRequest_ESTIMATED_RESOURCES').val();
    var estimatedPersonnel = $('#theRequest_ESTIMATED_PERSONNEL_COST').val();
    sum = estimatedResources + estimatedPersonnel; 

    if (!isNaN(sum)) {
        $('#theRequest_GRAND_TOTAL').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));        
    }
    else {
        $('#theRequest_GRAND_TOTAL').val(parseFloat(0.00, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));   
    }

};

function calculateTaxes(parent, cost) {
    var taxId = parseFloat(parent.find('#theLineItem_TAX_RATE_ID').val()); // get value of field
    //var cost = parseFloat(parent.find('#theLineItem_EXT_COST').val()); // convert it to a float        

    if (!isNaN(taxId) && !isNaN(cost)) { //if there's a value do the calculation

        $.ajax({
            //dataType: "json",
            url: '../../Requests/GetTaxRate',
            dataType: 'json',
            data: { taxId: taxId },
            success: function (data) {
                var sum = data * cost;
                parent.find('#theLineItem_TAX_AMOUNT').val(parseFloat(sum, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,"));
                calculateLineItemSubTotal(parent);
                calculateShippingTotal();
                calculateTaxTotal();
                calculateTotalLineItem();
                calculateGrandTotalForLineItems();
            },
            error: function (xhr, ajaxOptions, error) {
                alert('Error has occured.  Please contact application administrators and reference the following: GetAdjustedSalary ' + xhr.status);
            }
        });
    }
};


//Formatting for Hours Per Day & FTE

$(document).ready(function () {
    // Get Rid of NAN by adding value before calculation    
    var value = $('#theStaffingRequest_HOURS_PER_DAY').val();
    //if (value.length) {
        
    //}
    //else {

    //}
});


