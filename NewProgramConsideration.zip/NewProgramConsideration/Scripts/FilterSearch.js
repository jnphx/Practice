﻿/* File Created: April 26, 2017 */

$(document).ready(function () {
    var getUrl = window.location;
    var baseUrl = "";
    if (location.hostname === "localhost" || location.hostname === "127.0.0.1") {
        baseUrl = getUrl.protocol + "//" + getUrl.host + "/";
    }
    else {
        baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1] + "/";
    }
    window.BaseUrl = baseUrl;   
});

//Request search functions
$('#txtSearchRequest').keypress(function (e) {
    if (e.which == 13) {
        //        $('#theStudent_StudentId').get(0).selectedIndex = 0;
        $(".searchingDiv").removeClass("hidden");
        var searchString = $('#txtSearchRequest').val();
        var status = $("#ddlFilterStatus option:selected").text();
        var requestor = $("#ddlFilterRequestor").val();
        var school = $("#ddlFilterLocation").val();
        var year = $("#ddlFilterYear").val();
        LoadRequestSearchResult(searchString, status, null, requestor, school, year, false);
        return false;
    }
});

$(document).on('click', "#btnRequestSearch", function () {
    $(".searchingDiv").removeClass("hidden");
    var searchString = $('#txtSearchRequest').val();
    var status = $("#ddlFilterStatus option:selected").text();
    var requestor = $("#ddlFilterRequestor").val();
    var school = $("#ddlFilterLocation").val();
    var year = $("#ddlFilterYear").val();
    LoadRequestSearchResult(searchString, status, null, requestor, school, year, false);
    return false;
});

$(document).on('click', "#btnDefaultRequest", function () {
    $(".searchingDiv").removeClass("hidden");
    $('#txtSearchRequest').val("");
    var searchString = $('#txtSearchRequest').val();
    var status = $("#ddlFilterStatus option:selected").text();
    var requestor = $("#ddlFilterRequestor").val();
    var school = $("#ddlFilterLocation").val();
    var year = $("#ddlFilterYear").val();
    var sortby = "RequestId";
    LoadRequestSearchResult(searchString, status, sortby, requestor, school, year, false);
    return false;
});

$(document).on('change', "#ddlFilterStatus", function () {
    $(".searchingDiv").removeClass("hidden");
    var searchString = $('#txtSearchRequest').val();
    var status = $("#ddlFilterStatus option:selected").text();
    var requestor = $("#ddlFilterRequestor").val();
    var school = $("#ddlFilterLocation").val();
    var year = $("#ddlFilterYear").val();
    LoadRequestSearchResult(searchString, status, null, requestor, school, year, false);
});

$(document).on('change', "#ddlFilterLocation", function () {
    $(".searchingDiv").removeClass("hidden");
    var searchString = $('#txtSearchRequest').val();
    var status = $("#ddlFilterStatus option:selected").text();
    var requestor = $("#ddlFilterRequestor").val();
    var school = $("#ddlFilterLocation").val();
    var year = $("#ddlFilterYear").val();
    LoadRequestSearchResult(searchString, status, null, requestor, school, year, false);
});

$(document).on('change', "#ddlFilterRequestor", function () {
    $(".searchingDiv").removeClass("hidden");
    var searchString = $('#txtSearchRequest').val();
    var status = $("#ddlFilterStatus option:selected").text();
    var requestor = $("#ddlFilterRequestor").val();
    var school = $("#ddlFilterLocation").val();
    var year = $("#ddlFilterYear").val();
    LoadRequestSearchResult(searchString, status, null, requestor, school, year, false);
});

$(document).on('change', "#ddlFilterYear", function () {
    $(".searchingDiv").removeClass("hidden");
    var searchString = $('#txtSearchRequest').val();
    var status = $("#ddlFilterStatus option:selected").text();
    var requestor = $("#ddlFilterRequestor").val();
    var school = $("#ddlFilterLocation").val();
    var year = $("#ddlFilterYear").val();
    LoadRequestSearchResult(searchString, status, null, requestor, school, year, false);
});

//$(document).on('click', ".sort", function () {
//    var txt = $(this).prop("class"); //grab class for sort decending command        
//    var sortBy = $(this).parent().prop("id");
//    var str = 'desc';
//    if (txt.indexOf(str) > -1) {
//        sortBy += " desc";
//    }
//    var searchString = $('#txtSearchRequest').val();
//    var status = $("#ddlFilterStatus option:selected").text();
//    var requestor = $("#ddlFilterRequestor").val();
//    var school = $("#ddlFilterLocation").val();
//    var year = $("#ddlFilterYear").val();
//    LoadRequestSearchResult(searchString, status, sortBy, requestor, school, year, false);
//});


//Review Requests
$('#txtSearchRequestReview').keypress(function (e) {
    if (e.which == 13) {
        $(".searchingDiv").removeClass("hidden");
        var searchString = $('#txtSearchRequestReview').val();
        var status = $("#ddlFilterStatusReview option:selected").text();
        var requestor = $("#ddlFilterRequestorReview").val();
        var school = $("#ddlFilterLocationReview").val();
        var year = $("#ddlFilterYearReview").val();
        //        LoadRequestSearchResult(searchString, status, null, requestor, school, year, true);
        LoadRequestSearchResult(searchString, status, null, requestor, school, year, "CapitalReviewView");
        return false;
    }
});

$(document).on('click', "#btnRequestSearchReview", function () {
    $(".searchingDiv").removeClass("hidden");
    var searchString = $('#txtSearchRequestReview').val();
    var status = $("#ddlFilterStatusReview option:selected").text();
    var requestor = $("#ddlFilterRequestorReview").val();
    var school = $("#ddlFilterLocationReview").val();
    var year = $("#ddlFilterYearReview").val();
    //    LoadRequestSearchResult(searchString, status, null, requestor, school, year, true);
    LoadRequestSearchResult(searchString, status, null, requestor, school, year, "CapitalReviewView");
    return false;
});

$(document).on('change', "#ddlFilterStatusReview", function () {
    $(".searchingDiv").removeClass("hidden");
    var searchString = $('#txtSearchRequestReview').val();
    var status = $("#ddlFilterStatusReview option:selected").text();
    var requestor = $("#ddlFilterRequestorReview").val();
    var school = $("#ddlFilterLocationReview").val();
    var year = $("#ddlFilterYearReview").val();
    //    LoadRequestSearchResult(searchString, status, null, requestor, school, year, true);
    LoadRequestSearchResult(searchString, status, null, requestor, school, year, "CapitalReviewView");
});

$(document).on('change', "#ddlFilterLocationReview", function () {
    $(".searchingDiv").removeClass("hidden");
    var searchString = $('#txtSearchRequestReview').val();
    var status = $("#ddlFilterStatusReview option:selected").text();
    var requestor = $("#ddlFilterRequestorReview").val();
    var school = $("#ddlFilterLocationReview").val();
    var year = $("#ddlFilterYearReview").val();
    //    LoadRequestSearchResult(searchString, status, null, requestor, school, year, true);
    LoadRequestSearchResult(searchString, status, null, requestor, school, year, "CapitalReviewView");
});

$(document).on('change', "#ddlFilterRequestorReview", function () {
    $(".searchingDiv").removeClass("hidden");
    var searchString = $('#txtSearchRequestReview').val();
    var status = $("#ddlFilterStatusReview option:selected").text();
    var requestor = $("#ddlFilterRequestorReview").val();
    var school = $("#ddlFilterLocationReview").val();
    var year = $("#ddlFilterYearReview").val();
    //    LoadRequestSearchResult(searchString, status, null, requestor, school, year, true);
    LoadRequestSearchResult(searchString, status, null, requestor, school, year, "CapitalReviewView");
});

$(document).on('change', "#ddlFilterYearReview", function () {
    $(".searchingDiv").removeClass("hidden");
    var searchString = $('#txtSearchRequestReview').val();
    var status = $("#ddlFilterStatusReview option:selected").text();
    var requestor = $("#ddlFilterRequestorReview").val();
    var school = $("#ddlFilterLocationReview").val();
    var year = $("#ddlFilterYearReview").val();
    //    LoadRequestSearchResult(searchString, status, null, requestor, school, year, true);
    LoadRequestSearchResult(searchString, status, null, requestor, school, year, "CapitalReviewView");
});


//Sorting
$(document).on('click', ".sort", function () {
    var txt = $(this).prop("class"); //grab class for sort decending command        
    var sortBy = $(this).parent().prop("id");
    var str = 'desc';
    if (txt.indexOf(str) > -1) {
        sortBy += " desc";
    }

    //    if ($("#hdfReview").length) {        
    //        var searchString = $('#txtSearchRequestReview').val(); alert(searchString);
    //        var status = $("#ddlFilterStatusReview option:selected").text(); alert(status);
    //        var requestor = $("#ddlFilterRequestorReview").val(); alert(requestor);
    //        var school = $("#ddlFilterLocationReview").val(); alert(school);
    //        var year = $("#ddlFilterYearReview").val(); alert(year);
    //        LoadRequestSearchResult(searchString, status, sortBy, requestor, school, year, true);
    //    }
    //    else {
    //        var searchString = $('#txtSearchRequest').val(); alert(searchString);
    //        var status = $("#ddlFilterStatus option:selected").text(); alert(status);
    //        var requestor = $("#ddlFilterRequestor").val(); alert(requestor);
    //        var school = $("#ddlFilterLocation").val(); alert(school);
    //        var year = $("#ddlFilterYear").val(); alert(year);
    //        LoadRequestSearchResult(searchString, status, sortBy, requestor, school, year, false);
    //    }

    switch ($("#hdfReview").val()) {
        case "ApprovalView":
            var searchString = "";
            var status = "Workflow Status Filter";
            var requestor = null;
            var school = null;
            var year = null;
            LoadRequestSearchResult(searchString, status, sortBy, requestor, school, year, "ApprovalView");
            break;
        case "ReviewView":
            var searchString = "";
            var status = "Workflow Status Filter";
            var requestor = null;
            var school = null;
            var year = null;
            LoadRequestSearchResult(searchString, status, sortBy, requestor, school, year, "ReviewView");
            break;
        case "CapitalReviewView":
            var searchString = $('#txtSearchRequestReview').val(); 
            var status = $("#ddlFilterStatusReview option:selected").text(); 
            var requestor = $("#ddlFilterRequestorReview").val(); 
            var school = $("#ddlFilterLocationReview").val(); 
            var year = $("#ddlFilterYearReview").val(); 
            LoadRequestSearchResult(searchString, status, sortBy, requestor, school, year, "CapitalReviewView");
            break;
        default:
            var searchString = $('#txtSearchRequest').val(); 
            var status = $("#ddlFilterStatus option:selected").text(); 
            var requestor = $("#ddlFilterRequestor").val(); 
            var school = $("#ddlFilterLocation").val(); 
            var year = $("#ddlFilterYear").val(); 
            LoadRequestSearchResult(searchString, status, sortBy, requestor, school, year, "");
            break;
    }
});

function LoadRequestSearchResult(searchString, status, sortBy, requestor, school, year, view) {
    var json = { "searchString": searchString, "status": status, "sortBy": sortBy, "view":view, "requestor": requestor, "school": school, "year": year };
    $.ajax({
        url: window.BaseUrl + "Requests/RequestSearchResult",
        type: "GET",
        data: json
    })
    .done(function (partialViewResult) {
        $("#targetRequest").html(partialViewResult);
    });
}


//User search functions
$('#txtSearchUser').keypress(function (e) {
    if (e.which == 13) {
        //        $('#theStudent_StudentId').get(0).selectedIndex = 0;
        var searchString = $('#txtSearchUser').val();
        var status = $("#ddlFilterUserStatus option:selected").text();
        var permission = $("#ddlFilterPermission").val();
        var school = $("#ddlFilterUserLocation").val();
        LoadUserSearchResult(searchString, status, null, permission, school);
        return false;
    }
});

$(document).on('click', "#btnUserSearch", function () {
    var searchString = $('#txtSearchUser').val();
    var status = $("#ddlFilterUserStatus option:selected").text();
    var permission = $("#ddlFilterPermission").val();
    var school = $("#ddlFilterUserLocation").val();
    LoadUserSearchResult(searchString, status, null, permission, school);
    return false;
});

$(document).on('click', "#btnDefaultUser", function () {
    $('#txtSearchUser').val("");
    var searchString = $('#txtSearchUser').val();
    var status = $("#ddlFilterUserStatus option:selected").text();
    var permission = $("#ddlFilterPermission").val();
    var school = $("#ddlFilterUserLocation").val();
    LoadUserSearchResult(searchString, status, null, permission, school);
    return false;
});

$(document).on('change', "#ddlFilterUserStatus", function () {
    var searchString = $('#txtSearchUser').val();
    var status = $("#ddlFilterUserStatus option:selected").text();
    var permission = $("#ddlFilterPermission").val();
    var school = $("#ddlFilterUserLocation").val();
    LoadUserSearchResult(searchString, status, null, permission, school);
});

$(document).on('change', "#ddlFilterUserLocation", function () {
    var searchString = $('#txtSearchUser').val();
    var status = $("#ddlFilterUserStatus option:selected").text();
    var permission = $("#ddlFilterPermission").val();
    var school = $("#ddlFilterUserLocation").val();
    LoadUserSearchResult(searchString, status, null, permission, school);
});

$(document).on('change', "#ddlFilterPermission", function () {
    var searchString = $('#txtSearchUser').val();
    var status = $("#ddlFilterUserStatus option:selected").text();
    var permission = $("#ddlFilterPermission").val();
    var school = $("#ddlFilterUserLocation").val();
    LoadUserSearchResult(searchString, status, null, permission, school);
});

$(document).on('click', ".sortUser", function () {
    var txt = $(this).prop("class"); //grab class for sort decending command        
    var sortBy = $(this).parent().prop("id");
    var str = 'desc';
    if (txt.indexOf(str) > -1) {
        sortBy += " desc";
    }
    var searchString = $('#txtSearchUser').val();
    var status = $("#ddlFilterUserStatus option:selected").text();
    var permission = $("#ddlFilterPermission").val();
    var school = $("#ddlFilterUserLocation").val();
    LoadUserSearchResult(searchString, status, sortBy, permission, school);
});

function LoadUserSearchResult(searchString, status, sortBy, permission, school) {
    var json = { "searchString": searchString, "status": status, "sortBy": sortBy, "permission": permission, "school": school };
    $.ajax({
        url: "Users/UserSearchResult",
        type: "GET",
        data: json
    })
    .done(function (partialViewResult) {
        $("#target").html(partialViewResult);
    });
}

// Position Name Sort

$(document).on('click', "#btnPositionSearch", function () {
    var searchString = $('#txtSearchPosition').val();
    LoadPositionSearchResult(searchString);
    return false;
});

$('#txtSearchPosition').keypress(function (e) {
    if (e.which == 13) {
        //        $('#theStudent_StudentId').get(0).selectedIndex = 0;
        var searchString = $('#txtSearchPosition').val();
        LoadPositionSearchResult(searchString, null);
        return false;
    }
});

$(document).on('click', ".sortPosition", function () {
    var txt = $(this).prop("class"); //grab class for sort descending command        
    var sortBy = $(this).parent().prop("id");
    var str = 'desc';
    if (txt.indexOf(str) > -1) {
        sortBy += " desc";
    }
    var searchString = $('#txtSearchPosition').val();
    LoadPositionSearchResult(searchString, sortBy);
});

$(document).on('click', "#btnDefaultPosition", function () {
    $('#txtSearchPosition').val("")
    var searchString = $('#txtSearchPosition').val();
    LoadPositionSearchResult(searchString);
    return false;
});

function LoadPositionSearchResult(searchString, sortBy) {
    var json = { "searchString": searchString, "sortBy": sortBy };
    $.ajax({
        url: "Positions/PositionSearchResult",
        type: "GET",
        data: json
    })
    .done(function (partialViewResult) {
        $("#target").html(partialViewResult);
    });
}


