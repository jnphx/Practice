﻿$(document).ready(function () {

    $('.next').click(function () {

        var nextId = $(this).parents('.tab-pane').next().attr("id");
        $('[href=#' + nextId + ']').tab('show');
        return false;

    })

    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {

        //update progress
        var step = $(e.target).data('step');
        var percent = (parseInt(step) / 5) * 100;

        $('.progress-bar').css({ width: percent + '%' });
        $('.progress-bar').text("Step " + step + " of 5");

        //e.relatedTarget // previous tab

    })

    $('.startOver').click(function () {

        $('#budgetWizard a:first').tab('show');

    })

});

//$("textarea#theRequest_NARRATIVE_STAFFING_NARRATIVE").focus(function () {
//    var textArea = $("textarea#theRequest_NARRATIVE_STAFFING_NARRATIVE").val();
//    if (textArea.replace(/^\s+|\s+$/g, "").length == 0 || textArea == "") {
//        $("textarea#theRequest_NARRATIVE_STAFFING_NARRATIVE").val("Position Control Number: \n" + "Student ID: \n" + "Student Name: ");
//    }
//});

$(document).on('click', ".add_line", function () {
    //    var parentDiv = $("#line_request_tbl");
    //    var newDiv = $("#line_request_row").clone();
    //    parentDiv.append(newDiv);
    //    newDiv.find('#theLineItem_TOTAL').val('');
    //    newDiv.find('#theLineItem_REQUESTED_LINE_ITEM').val('');
    //    newDiv.find('#theLineItem_QUANTITY').val('');
    //    newDiv.find('#theLineItem_COST').val('');
    //    newDiv.find('#theLineItem_EXT_COST').val('');
    //    newDiv.find('#theLineItem_TAX_RATE_ID').val('');
    //    newDiv.find('#theLineItem_TAX_AMOUNT').val('');
    //    newDiv.find('#theLineItem_SHIPPING').val('');
    //    newDiv.find('#theLineItem_CATEGORY_ID').val('');
    //    newDiv.find('#theLineItem_ACCT_CODE').val('');
    //    newDiv.find("#theLineItem_LINE_ITEM_ID").remove()
    AddLine();
    //calculateTaxTotal();
    //calculateGrandTotalForLineItems();
});

$(document).on('click', ".addItem", function () {
    var lastTr = $('#line_request_tbl tr:last');
    var item = lastTr.find("#theLineItem_REQUESTED_LINE_ITEM").val();
    var parent = $(this).parent().parent();
    var description = $(this).parent().parent().find(".nameCell").html();
    var qty = $(this).parent().parent().find(".qtyCell").html();
    var price = $(this).parent().parent().find(".priceCell").html();
    var ship = $(this).parent().parent().find(".shipCell").html();
    //$(this).parent().parent().find("#theLineItem_DECISION_ID").val("Pending Review");
    $('#theLineItem_DECISION_ID > option[value="4"]').prop('selected', true);

    if (item.length) {
        AddLine();
        AddStandardEquipment(description, price, qty, ship);
        $('#theLineItem_DECISION_ID > option[value="4"]').prop('selected', true);
    }
    else {
        AddStandardEquipment(description, price, qty, ship);
    }

    $('#standardEquip').on('hidden.bs.modal', function () {
        calculateGrandTotalForLineItems();
    });

});

$(document).on('click', ".addAllItems", function () {
    $("tr.item").each(function () {
        var lastTr = $('#line_request_tbl tr:last');
        var item = lastTr.find("#theLineItem_REQUESTED_LINE_ITEM").val();
        var description = $(this).find(".nameCell").html();
        var qty = $(this).find(".qtyCell").html();
        var price = $(this).find(".priceCell").html();
        var ship = $(this).find(".shipCell").html();
        $('#theLineItem_DECISION_ID > option[value="4"]').prop('selected', true);

        if (item.length) {
            AddLine();
            AddStandardEquipment(description, price, qty, ship);
            $('#theLineItem_DECISION_ID > option[value="4"]').prop('selected', true);
        }
        else {
            AddStandardEquipment(description, price, qty, ship);
            $('#theLineItem_DECISION_ID > option[value="4"]').prop('selected', true);

        }

        $('#standardEquip').on('hidden.bs.modal', function () {
            calculateGrandTotalForLineItems();
        });
    });
});

function AddLine() {
    //calculateTaxTotal();
    //calculateGrandTotalForLineItems();
    var parentDiv = $("#line_request_tbl");
    var newDiv = $("#line_request_row").clone();
    parentDiv.append(newDiv);
    newDiv.find('#theLineItem_TOTAL').val('');
    newDiv.find('#theLineItem_REQUESTED_LINE_ITEM').val('');
    newDiv.find('#theLineItem_QUANTITY').val('');
    newDiv.find('#theLineItem_COST').val('');
    newDiv.find('#theLineItem_EXT_COST').val('');
    newDiv.find('#theLineItem_TAX_RATE_ID').val('');
    newDiv.find('#theLineItem_TAX_AMOUNT').val('');
    newDiv.find('#theLineItem_SHIPPING').val('');
    newDiv.find('#theLineItem_CATEGORY_ID').val('');
    newDiv.find('#theLineItem_ACCT_CODE').val('');
    newDiv.find("#theLineItem_LINE_ITEM_ID").remove();
    $('#theLineItem_DECISION_ID > option[value="4"]').prop('selected', true);
}

function AddStandardEquipment(description, price, qty, ship) {    
    var parent = $('#line_request_tbl tr:last');
    parent.find('#theLineItem_REQUESTED_LINE_ITEM').val(description);
    parent.find('#theLineItem_QUANTITY').val(qty);
    parent.find('#theLineItem_COST').val(price);
    parent.find('#theLineItem_SHIPPING').val(ship);
    LineItemCalculations(parent);
    //$.each(newOptions, (function () {
    //    $('[name=theLineItem.DECISION_ID] option').filter(function () {
    //        return ($(this).text() == 'PENDING REVIEW'); //To select Pending Review
    //    }).prop('selected', true);
    //})
}

$(document).on('click', ".remove_line", function () {
    if ($(".first").length > 1) {
        $(this).parent().parent("tr").remove();
        calculateTaxTotal();
        calculateGrandTotalForLineItems();
    }
    else {
        var temp = 0;
        $(this).parent().parent().find('#theLineItem_LINE_ITEM_ID').val('');
        $(this).parent().parent().find('#theLineItem_TOTAL').val('');
        $(this).parent().parent().find('#theLineItem_REQUESTED_LINE_ITEM').val('');
        $(this).parent().parent().find('#theLineItem_QUANTITY').val('');
        $(this).parent().parent().find('#theLineItem_COST').val('');
        $(this).parent().parent().find('#theLineItem_EXT_COST').val('');
        $(this).parent().parent().find('#theLineItem_TAX_RATE_ID').val('');
        $(this).parent().parent().find('#theLineItem_TAX_AMOUNT').val('');
        $(this).parent().parent().find('#theLineItem_SHIPPING').val('');
        $(this).parent().parent().find('#theLineItem_CATEGORY_ID').val('');
        $(this).parent().parent().find('#theLineItem_ACCT_CODE').val('');
        $(this).parent().parent().find("#theLineItem_LINE_ITEM_ID").remove();
        calculateTaxTotal();
        calculateGrandTotalForLineItems();
        if ($('.lineItemGrandTotal').val() > 0) {
            $('.lineItemGrandTotal').val("0.00");
        }
    }

    calculateShippingTotal();
    calculateTotalLineItem();
});

//$(document).ready(function () {
//    $('#budgetWizard').modal('show');
//    $('.nav a:not(".external")').click(function (e) {
//        e.preventDefault()
//        $(this).tab('show')
//    })
//});