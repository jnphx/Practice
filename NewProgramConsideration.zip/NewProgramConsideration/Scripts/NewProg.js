﻿$(document).on('click', ".add_role", function () {
    var newDiv = $("#loc-user").find(".loc-in-use:first-child").clone();
    newDiv.find("#locationsSelected").val('');
    newDiv.find("#LocationUsingProgramId").val("0");    
    $("#loc-user").append(newDiv);

});

$(document).on('click', ".remove_role", function () {
    var parentDiv = $(this).parent(".loc-in-use");
    if ($(".loc-in-use").length > 1) {
        parentDiv.remove();
    }
    else {
        //only one section left, cant remove so reset        
        parentDiv.find("#locationsSelected").val('');
        parentDiv.find("#LocationUsingProgramId").val("0");
    }
});

