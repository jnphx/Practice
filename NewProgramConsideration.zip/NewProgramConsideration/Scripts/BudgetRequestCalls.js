﻿/* File Created: February 1, 2017 */

$(document).ready(function () {
    $(".editDdl").each(function () {
        var id = $(this).data("selected");
        $(this).val(id);
    });

    $(".datetimepicker100").datetimepicker({
        //minDate: moment(),
        format: 'MM/DD/YYYY'
    });

    $(".effectiveDate").each(function () {
        var id = $(this).data("effdate");
        $(this).val(id);
    });

    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
});

$(document).on('click', ".glyphicon-chevron-right", function () {
    var header = $(this).data("header"); 
    $("." + header).removeClass("hidden");
    $(this).addClass("glyphicon-chevron-down").removeClass("glyphicon-chevron-right");

});

$(document).on('click', ".glyphicon-chevron-down", function () {
    var header = $(this).data("header");
    $("." + header).addClass("hidden");
    $(this).removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-right");
});

$(document).on('click', ".showComments", function () {
    var openDiv = $(this).parent().parent().parent();
    openDiv.find(".commentBox").removeClass("hidden");
    openDiv.removeClass("showComments").addClass("closeComments");
    openDiv.find(".commentHeader").html("Hide Comments");
});

$(document).on('click', ".closeComments", function () {
    var closeDiv = $(this).parent().parent().parent();
    closeDiv.find(".commentBox").addClass("hidden");
    closeDiv.find(".firstComment").removeClass("hidden");
    closeDiv.removeClass("closeComments").addClass("showComments");
    closeDiv.find(".commentHeader").html("Show All Comments");
});

$(document).on('click', ".showStaffAmounts", function () {
    var openDiv = $(this).parents(".positionContainer"); 
    openDiv.find(".combine").removeClass("hidden");
    $(this).removeClass("showStaffAmounts").addClass("hideStaffAmounts");
    $(openDiv).find(".staffCalc").each(function () {
        $(this).removeClass("hidden");
    });
});

$(document).on('click', ".hideStaffAmounts", function () {
    var openDiv = $(this).parents(".positionContainer");
    var isSped = openDiv.find("#staff_IS_SPED").is(':checked');
    if (isSped) {
        openDiv.find(".combine").removeClass("hidden");        
    }
    else
    {        
        openDiv.find(".combine").addClass("hidden");
    }
    $(this).removeClass("hideStaffAmounts").addClass("showStaffAmounts");
    $(openDiv).find(".staffCalc").each(function () {
        $(this).addClass("hidden");
    });
});

$(document).on('click', ".add_staff", function () {
    var parentDiv = $("#staff_request_tbl");
    var newDiv = $("#staff_request_row").clone();
    newDiv.find("#theStaffingRequest_STAFFING_REQUEST_ID").remove();  //need to remove staffing request id as this will be a new request
    parentDiv.append(newDiv);

    //clearing values
    //    parentDiv.find('#theStaffingRequest_POSITION_ID').val('');
    //    parentDiv.find('#theStaffingRequest_STAFFING_TYPE_ID').val(''); 
    newDiv.find('#theStaffingRequest_HOURS_PER_DAY').val('0.00');
    newDiv.find('#theStaffingRequest_DAYS_PER_WEEK').val('0.00');
    newDiv.find('#theStaffingRequest_FTE').val('0.00');
    newDiv.find('#theStaffingRequest_ACTUAL_SALARY').val('');
    newDiv.find('#theStaffingRequest_ADJ_ACTUAL_SALARY').val('');
    newDiv.find('#theStaffingRequest_EFFECTIVE_DATE').val('');
    newDiv.find('#thePosition_AVG_SALARY').val('');
    newDiv.find('#theStaffingRequest_BENEFITS').val('');
    newDiv.find('#theStaffingRequest_INSURANCE').val('');
    newDiv.find('#theStaffingRequest_GRAND_TOTAL').val('');
    newDiv.find('#theStaffingRequest_SPED_POSITION_CONTROL').val('');
    newDiv.find('#theStaffingRequest_STUDENT_NAME').val('');
    newDiv.find('#theStaffingRequest_STUDENT_ID').val('');
    newDiv.find('#theStaffingRequest_GRADE').val('');
    newDiv.find('#staff_IS_SPED').prop("checked", false);
    newDiv.find('.sped').addClass("hidden");

    $(".datetimepicker100").datetimepicker({
        minDate: moment(),
        format: 'MM/DD/YYYY'
    });
});

$(document).on('click', ".remove_staff", function () {
    if ($(".first").length > 1) {
        $(this).parents(".first").remove();
    }
    else {
        $(this).parent().parent().find('#theStaffingRequest_POSITION_ID').val('');
        $(this).parent().parent().find('#theStaffingRequest_STAFFING_TYPE_ID').val('');
        $(this).parent().parent().find('#theStaffingRequest_HOURS_PER_DAY').val('');
        $(this).parent().parent().find('#theStaffingRequest_DAYS_PER_WEEK').val('');
        $(this).parent().parent().find('#theStaffingRequest_FTE').val('');
        $(this).parent().parent().find('#theStaffingRequest_ACTUAL_SALARY').val('');
        $(this).parent().parent().find('#theStaffingRequest_ADJ_ACTUAL_SALARY').val('');
        $(this).parent().parent().find('#theStaffingRequest_EFFECTIVE_DATE').val('');
        $(this).parent().parent().find('#thePosition_AVG_SALARY').val('');
        $(this).parent().parent().find('#theStaffingRequest_BENEFITS').val('');
        $(this).parent().parent().find('#theStaffingRequest_INSURANCE').val('');
        $(this).parent().parent().find('#theStaffingRequest_GRAND_TOTAL').val('');
        $(this).parent().parent().find('#theStaffingRequest_SPED_POSITION_CONTROL').val('');
        $(this).parent().parent().find('#theStaffingRequest_STUDENT_NAME').val('');
        $(this).parent().parent().find('#theStaffingRequest_STUDENT_ID').val('');
        $(this).parent().parent().find('#theStaffingRequest_GRADE').val('');
        $(this).parent().parent().find('#staff_IS_SPED').prop("checked", false);
        $(this).parent().parent().find('.sped').addClass("hidden");
    }

    calculateTotalSalaries();
    calculateTotalBenefits();
    calculateTotalInsurance();
    calculateTotal();
});

$(document).on('click', ".addRequestComment", function () {
    var commentType = $(this).parent().attr("data-commenttype");
    $("#hdfCommentType").val(commentType);
    //var requestModal = $(this).parent().find("#addRequestComment"); 
    //var btn = requestModal.find("#addReqComment");
    //btn.attr('data-commenttype', commentType);
});

$(document).on('click', "#addReqComment", function () {
    var requestId = $('#theRequest_REQUEST_ID').val();
    var comment = $('#theComment_CONTENT').val();
    var parentModal = $(this).parents("#addRequestComment");
    //var commentType = $(this).attr("data-commenttype");
    var commentType = $("#hdfCommentType").val();
    var isPublic = true;
    if ($('#theComment_IsPUBLIC').length > 0) {
        if ($('#theComment_IsPUBLIC').prop('checked')) {
            isPublic = true;
        }
        else {
            isPublic = false;
        }
    }

    var json = { requestId: requestId, comment: comment, isPublic: isPublic, commentType: commentType };
    $.ajax({
        type: "POST",
        url: "../../Requests/AddRequestComment",
        contentType: "application/json; charset=utf-8",
        data: JSON.stringify(json),
        dataType: "json",
        success: function (data) {
            if (data == true) {
                UpdateCommentsPartial(requestId, commentType);
            }

            parentModal.find("theComment_CONTENT").val();
            parentModal.toggle();
        },
        error: function (xhr, ajaxOptions, error) {
            alert('Error has occured.  Please contact application administrators and reference the following: AddRequestComment ' + xhr.status);
        }
    });
});

function UpdateCommentsPartial(requestId, commentType) {
    if (commentType !== 0) {
        var origCommentType = commentType;
        $.ajax({
            //dataType: "json",
            url: '../../Requests/UpdateCommentsPartial',
            cache: false,
            async: true,
            type: "POST",
            data: { "requestId": requestId, "commentType": commentType },
            success: function (data) {
                CloseModal();                
                switch (origCommentType)
                {
                    case "1":
                        $('#finCommentDivInfo').html(data);
                        break;
                    case "2":                        
                        $('#finCommentDivStaff').html(data);
                        break;
                    case "3":                        
                        $('#finCommentDivOther').html(data);
                        break;
                }                
            },
            error: function (xhr, ajaxOptions, error) {
                alert('Error has occured.  Please contact application administrators and reference the following: UpdateCommentsPartial ' + xhr.status);
            }
        });
    }

    commentType = 0;
    $.ajax({
        //dataType: "json",
        url: '../../Requests/UpdateCommentsPartial',
        cache: false,
        async: true,
        type: "POST",
        data: { "requestId": requestId, "commentType": commentType },
        success: function (data) {
            CloseModal();            
            $('.commentsTableDiv').html(data);
        },
        error: function (xhr, ajaxOptions, error) {
            alert('Error has occured.  Please contact application administrators and reference the following: UpdateCommentsPartial ' + xhr.status);
        }
    });
//    $.ajax({
//        //dataType: "json",
//        url: '../../Requests/UpdateCommentsPartial',
//        dataType: 'json',
//        data: { requestId: requestId },
//        success: function (data) {
//            CloseModal();
//            $('.commentsTableDiv').html(data);
//        },
//        error: function (xhr, ajaxOptions, error) {
//            alert('Error has occured.  Please contact application administrators and reference the following: UpdateCommentsPartial ' + xhr.status);
//        }
//    });
}

$(document).on('change', "#theStaffingRequest_DECISION_ID", function () {
    var decision = $(this).val();
    $("#hdfStaffingRequestId").val($(this).data("staffid"));
    $("#hdfOrigStaffDec").val($(this).data("selected"));
    $(this).addClass("selectedStaffRequest");
    var div = $("#staffApproveComment #decisionBtn");
    div.empty();
    var closeBtn = "<button type=\"button\" class=\"btn btn-default decisionStaffClose\" data-dismiss=\"modal\">Cancel</button>";
    
        switch (decision) {
            case "1":
                $('.verbiage').html('Please provide a reason for the APPROVE decision (OPTIONAL)');
                var btn = "<input type=\"submit\" name=\"Command\" value=\"APPROVE STAFF\" id=\"btn\" class=\"btn btn-success\" />"
                break;
            case "2":
                $('.verbiage').html('Please provide a reason for the DENY decision (REQUIRED)');
                var btn = "<input type=\"submit\" name=\"Command\" value=\"DENY STAFF\" id=\"btn\" class=\"btn btn-danger\" />"
                break;
            case "3":
                $('.verbiage').html('Please provide a reason for the HOLD decision (REQUIRED)');
                var btn = "<input type=\"submit\" name=\"Command\" value=\"HOLD STAFF\" id=\"btn\" class=\"btn btn-danger\" />"
                break;
            case "4":
                $('.verbiage').html('Please provide a reason for the PENDING decision (OPTIONAL)');
                var btn = "<input type=\"submit\" name=\"Command\" value=\"PENDING STAFF\" id=\"btn\" class=\"btn btn-primary\" />"
                break;
            case "5":
                $('.verbiage').html('Please provide a reason for the TRANSFER decision (REQUIRED)');
                var btn = "<input type=\"submit\" name=\"Command\" value=\"TRANSFER STAFF\" id=\"btn\" class=\"btn btn-primary\" />"
                break;
        }    
        div.append(btn);
        div.append(closeBtn);
        $('#staffApproveComment').modal('toggle');
    
});

$(document).on('click', ".decisionStaffClose", function () {
    var origDec = $("#hdfOrigStaffDec").val();
    $('.selectedStaffRequest').val(origDec); 
    $('.selectedStaffRequest').removeClass("selectedStaffRequest");
});

$(document).on('click', ".staffReq", function () {
    var selectedPos = true;
    $(".posId").each(function () {
        if ($(this).val().length == 0) {
            $(this).css("background-color", "#ffebcd");
            selectedPos = false;
        }
        else {
            $(this).css("background-color", "#fff");
        }
    });

    if (selectedPos) {
        return true;
    }
    else {

        $("#staffPosReq").modal('toggle');
        return false;
    }
});

$(document).on('click', "#staff_IS_SPED", function () {
    var isSped = false;
    var parent = $(this).parents("tr");
    var staffCalc = parent.find(".staffingPosition");

    if ($(this).is(':checked'))
    {
        isSped = true;
    }

    if (isSped) {
        parent.find(".combine").removeClass("hidden");

        parent.find(".sped").each(function () {
            $(this).find(".spedVal").val("");
            $(this).removeClass("hidden");
        });
    }
    else {        
        if (staffCalc.hasClass("showStaffAmounts")) {
            parent.find(".combine").addClass("hidden");            
        }

        parent.find(".sped").each(function () {
            $(this).val("");
            $(this).addClass("hidden");
        });
    }
});



$(document).on('change', "#theLineItem_CATEGORY_ID", function () {
    if ($(this).val().length > 0) {
        $(this).parent().parent().find("#theLineItem_DECISION_ID").prop('disabled', false).removeClass("readonly");
    }
    else {
        $(this).parent().parent().find("#theLineItem_DECISION_ID").prop('disabled', true).addClass("readonly");
    }
});

$(document).on('change', "#theLineItem_DECISION_ID", function () {
    var decision = $(this).val();
    $("#hdfLineRequestId").val($(this).data("lineid"));
    $("#hdfOrigLineDec").val($(this).data("selected"));
    $(this).addClass("selectedLineRequest");
    var div = $("#lineApproveComment #decisionBtn");
    div.empty();
    var closeBtn = "<button type=\"button\" class=\"btn btn-default decisionClose\" data-dismiss=\"modal\">Close</button>";
    
    switch (decision) {
        case "1":
            $('.verbiage').html('Please provide a reason for the APPROVE decision (OPTIONAL)');
            var btn = "<input type=\"submit\" name=\"Command\" value=\"APPROVE RESOURCE\" id=\"btn\" class=\"btn btn-success\" />"
            break;
        case "2":
            $('.verbiage').html('Please provide a reason for the DENY decision (REQUIRED)');
            var btn = "<input type=\"submit\" name=\"Command\" value=\"DENY RESOURCE\" id=\"btn\" class=\"btn btn-danger\" />"
            break;
        case "3":
            $('.verbiage').html('Please provide a reason for the HOLD decision (REQUIRED)');
            var btn = "<input type=\"submit\" name=\"Command\" value=\"HOLD RESOURCE\" id=\"btn\" class=\"btn btn-warning\" />"
            break;
        case "4":
            $('.verbiage').html('Please provide a reason for the PENDING decision (OPTIONAL)');
            var btn = "<input type=\"submit\" name=\"Command\" value=\"PENDING RESOURCE\" id=\"btn\" class=\"btn btn-primary\" />"
            break;
        case "5":
            $('.verbiage').html('Please provide a reason for the TRANSFER decision (REQUIRED)');
            var btn = "<input type=\"submit\" name=\"Command\" value=\"TRANSFER RESOURCE\" id=\"btn\" class=\"btn btn-danger\" />"
            break;
    }
    div.append(btn);
    div.append(closeBtn);
    $('#lineApproveComment').modal('toggle');
    
});

$(document).on('click', ".decisionClose", function () {
    var origDec = $("#hdfOrigLineDec").val();
    $('.selectedLineRequest').val(origDec);
    $('.selectedLineRequest').removeClass("selectedLineRequest");
});

function CloseModal() {
    $('body').removeClass('modal-open').removeAttr('style');
}

$(document).on('click', ".rejectResubmit", function () {
    var decision = $(this).val();        
    var div = $("#rejectComment #wfDecisionBtn");
    div.empty();
    var closeBtn = "<button type=\"button\" class=\"btn btn-default \" data-dismiss=\"modal\">Cancel</button>";
    $('.verbiage').html('Please provide a reason for the RESUBMIT WITH CHANGES decision (REQUIRED)');
    var btn = "<input type=\"submit\" name=\"Command\" value=\"RESUBMIT WITH CHANGES\" id=\"btn\" class=\"btn btn-warning\" />"
    
    div.append(btn);
    div.append(closeBtn);
    //$('#rejectComment').modal('toggle');

});

$(document).on('click', ".denyStep", function () {
    var decision = $(this).val();
    var div = $("#rejectComment #wfDecisionBtn");
    div.empty();
    var closeBtn = "<button type=\"button\" class=\"btn btn-default \" data-dismiss=\"modal\">Cancel</button>";
    $('.verbiage').html('Please provide a reason for the DENY decision (REQUIRED)');
    var btn = "<input type=\"submit\" name=\"Command\" value=\"DENY\" id=\"btn\" class=\"btn btn-warning\" />"

    div.append(btn);
    div.append(closeBtn);
    //$('#rejectComment').modal('toggle');

});