﻿/* File Created: April 14, 2017 */
$(document).ready(function () {
    var getUrl = window.location;
    var baseUrl = "";
    if (location.hostname === "localhost" || location.hostname === "127.0.0.1") {
        baseUrl = getUrl.protocol + "//" + getUrl.host + "/";
    }
    else {
        baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1] + "/";
    }
    window.BaseUrl = baseUrl;
});


$(document).on('click', ".remove-document", function () {
    var documentId = $(this).data("id");
    var id = $("#theRequest_REQUEST_ID").val();
   
    var json = { id: id };
    $.ajax({
        type: "POST",
        url: window.BaseUrl + "Requests/RemoveDocument",
        cache: false,
        async: true,        
        data: { id: id, documentId: documentId },
        //        dataType: "json",
        success: function (data) {
            $('.documentsDiv').html(data);
        },
        error: function (xhr, ajaxOptions, error) {
            alert('Error has occured.  Please contact application administrators and reference the following: RemoveDocument ' + xhr.status);
        }
    });
});


