namespace NewProgramConsideration.Migrations
{
    using NewProgramConsideration.Models;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<NewProgramConsideration.Infrastructure.DataContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
        }

        protected override void Seed(NewProgramConsideration.Infrastructure.DataContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.
            var pos = new POSITION() { POSITION_NAME = "Web developer" };
            context.POSITIONS.AddOrUpdate(x => x.POSITION_ID,
                new POSITION()
                {
                    POSITION_NAME = "Principal"
                },
                pos);

            var jnel = new APP_USER()
            {
                APP_USER_NAME = "jnelson2",
                FIRST_NAME = "Jennifer",
                LAST_NAME = "Nelson",
                EMAIL = "Jennifer.Nelson@wesdschools.org",
                IS_ACTIVE = true,
                POSITION = pos
            };
            context.APP_USERS.AddOrUpdate(x => x.APP_USER_ID,
              jnel
                );
                
            var loc = new LOCATION()
            {
                LOCATION_NAME = "527 - Technology Services",
                LOCATION_CODE = "527"
            };
            var loc2 = new LOCATION()
            {
                LOCATION_NAME = "167-Abraham Lincoln",
                LOCATION_CODE = "167-AL"
            };
            context.LOCATIONS.AddOrUpdate(x => x.LOCATION_ID,
                loc2,
                new LOCATION()
                {
                    LOCATION_NAME = "114 - Acacia",
                    LOCATION_CODE = "114 - AC"
                },
                loc);

            var admin = new USER_ROLE()
            {
                NAME = "Admin",
            };

            context.USER_ROLES.AddOrUpdate(x => x.USER_ROLE_ID,
                admin);
            
            context.LOCATION_USER_ROLES.AddOrUpdate(x => x.LOCATION_USER_ROLE_ID,
                new LOCATION_USER_ROLE()
                {
                    LOCATION = loc,
                    APP_USER = jnel,
                    USER_ROLE = admin
                });
                
            var progcons = new PROGRAM_CONSIDERATION()
            {
                SUBMIT_DATE = new DateTime(2021, 6, 7),
                OPENING_CONTEXT = "unknown",
                SCHOOL_DEPT_REQUESTOR = loc,
                IDENTIFIED_NEED = "unknown",
                ANTICIPATED_OUTCOME = "unknown",
                ALTERNATIVE_OPTION = "unknown",
                DOCUMENTATION = "unknown",
                AVAIL_FUNDS = "unknown",
                SIMILAR_PROGRAM = "unknown",
                DISPLACED_PROGRAM = "unknown",
                EXPANSION = "unknown",
                COMPATIBILITY = "unknown",
                HAS_PRINCIPAL_SUPPORT = "unknown",
                HAS_CAPITAL_PROJECT_SUPPORT = "unknown",
                HAS_TRANSPORTATION_SUPPORT = "unknown",
                HAS_MIS_SUPPORT = "unknown",
                HAS_ACADEMIC_SERVICES_SUPPORT = "unknown",
                HAS_NUTRITION_SERVICES_SUPPORT = "unknown",
                NEED_EXPLANATION = "unknown",
                BENEFIT_EXPLANATION = "unknown",
                IS_DELETED = false
            };

            context.PROGRAM_CONSIDERATIONS.AddOrUpdate(x => x.PROGRAM_CONSIDERATION_ID,
                progcons);

            context.PROGRAMS.AddOrUpdate(x => x.PROGRAM_ID,
                new PROGRAM()
                {
                    LOCATION = loc2,
                    CONTACT = "Dan Stan",
                    EMAIL = "dan.stan@wesdschools.org",
                    PHONE = "602-580-2852",
                    PROGRAM_NAME = "unknown",
                    PROGRAM_DESCRIPTION = "unknown",
                    NUM_STUDENTS = 30,
                    NUM_STAFF = 2,
                    PROPOSED_IMPLEMENTATION = "unknown",
                    PROGRAM_CONSIDERATION = progcons,
                    COMPLETED_BY = new DateTime(2022, 2, 1),
                    DOCUMENT = "unknown"
                });

            context.BUDGETS.AddOrUpdate(x => x.BUDGET_ID,
                new BUDGET()
                {
                    START_UP_COSTS = 70000,
                    START_UP_DETAILS = "unknown",
                    IMPLEMENTATIONS_COSTS = 35000,
                    IS_ONGOING_COST = true,
                    ONGOING_COST = 25000,
                    IS_BUDGET_AVAIL = true,
                    BUDGET_AVAIL_DETAIL = "unknown",
                    IS_ADD_STAFF_REQD = true,
                    ADD_STAFF_DETAIL = "unknown",
                    ADD_STAFF_COST = 95000,
                    IS_PROF_DEV_REQD = false,
                    PROF_DEV_DETAIL = "unknown",
                    PROF_DEV_COST = 0,
                    IS_ADD_INSTRUCT_REQD = true,
                    ADD_INSTRUCT_DETAIL = "unknown",
                    ADD_INSTRUCT_COST = 3250,
                    IS_ADD_EQUIP_REQD = true,
                    ADD_EQUIP_DETAIL = "unknown",
                    ADD_EQUIP_COST = 29000,
                    IS_SITE_RENOVATION_REQD = false,
                    SITE_RENOVATION_DETAIL = "unknown",
                    SITE_RENOVATION_COST = 0,
                    PROGRAM_CONSIDERATION = progcons
                });

            context.STAKEHOLDER_GROUPS.AddOrUpdate(x => x.STAKEHOLDER_GROUP_ID,
                new STAKEHOLDER_GROUP()
                {
                    STAKEHOLDER_GROUP_NAME = "School Principal",
                    STAKEHOLDER_GROUP_IMPACT_DESCRIPTION = "Any school specific program"
                },
                new STAKEHOLDER_GROUP()
                {
                    STAKEHOLDER_GROUP_NAME = "Capital Projects",
                    STAKEHOLDER_GROUP_IMPACT_DESCRIPTION = "May require facility or site changes"
                },
            new STAKEHOLDER_GROUP()
            {
                STAKEHOLDER_GROUP_NAME = "Transportation",
                STAKEHOLDER_GROUP_IMPACT_DESCRIPTION = "If changes or requires addition of transportation"
            },
            new STAKEHOLDER_GROUP()
            {
                STAKEHOLDER_GROUP_NAME = "MIS",
                STAKEHOLDER_GROUP_IMPACT_DESCRIPTION = "Allowable equipment, need for infrastructure"
            },
            new STAKEHOLDER_GROUP()
            {
                STAKEHOLDER_GROUP_NAME = "EdTech",
                STAKEHOLDER_GROUP_IMPACT_DESCRIPTION = "Student data, online programs/software"
            },
            new STAKEHOLDER_GROUP()
            {
                STAKEHOLDER_GROUP_NAME = "Academic Services",
                STAKEHOLDER_GROUP_IMPACT_DESCRIPTION = "Anything related to curriculum/instruction"
            },
            new STAKEHOLDER_GROUP()
            {
                STAKEHOLDER_GROUP_NAME = "Nutrition Services",
                STAKEHOLDER_GROUP_IMPACT_DESCRIPTION = "requires meals, use of kitchen"
            });

        }
    }
}
