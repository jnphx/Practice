﻿using NewProgramConsideration.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NewProgramConsideration.ViewModels
{
    public class UserViewModel
    {
        public APP_USER theUser { get; set; }
        public IEnumerable<SelectListItem> DdlUserRoles { get; set; }
        public IEnumerable<SelectListItem> DdlLocations { get; set; }
        public IEnumerable<SelectListItem> ChkLocations { get; set; }
        public IEnumerable<SelectListItem> locationUserRolesId { get; set; }
        public IEnumerable<SelectListItem> locationsSelected { get; set; }
        public IEnumerable<SelectListItem> rolesSelected { get; set; }

        public PROGRAM theProgram { get; set; }

        public PROGRAM_CONSIDERATION theProgramConsid { get; set; }
    }
}