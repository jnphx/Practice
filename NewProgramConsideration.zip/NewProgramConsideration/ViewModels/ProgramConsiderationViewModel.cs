﻿using NewProgramConsideration.Infrastructure;
using NewProgramConsideration.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NewProgramConsideration.ViewModels
{
    public class ProgramConsiderationViewModel
    {
        private DataContext context = new DataContext();
        public IEnumerable<LOCATION> Locations { get; set; }

        public PROGRAM_CONSIDERATION theProgramConsideration { get; set; }
        public IQueryable<PROGRAM_CONSIDERATION> PROGRAM_CONSIDERATIONS { get { return context.PROGRAM_CONSIDERATIONS; } }

        public bool isReadOnly { get; set; }
        public bool isEdit { get; set; }
        public bool canUploadFile { get; set; }

        public IEnumerable<SelectListItem> DdlLocations { get; set; }

        public IEnumerable<SelectListItem> DdlStakeholderGroups { get; set; }

        public IList<string> ImpactedDepartmentGroupList { get; set; }

        public class AffectedStakeHolderData
        {
            public int STAKEHOLDER_GROUP_ID { get; set; }
            public string STAKEHOLDER_GROUP_NAME { get; set; }
            public string STAKEHOLDER_GROUP_IMPACT_DESCRIPTION { get; set; }
            public bool Affected { get; set; }
        }

        //Used in ProgramContext adding locations
        public IList<int> LocationUsingProgramId { get; set; }
        public IList<int> locationsSelected { get; set; }
    }
}