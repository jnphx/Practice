﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewProgramConsideration
{
    public class Constants
    {
        public enum MessageType
        {
            Error,
            Warning,
            Information
        }

        public static bool ValidUser { get; set; }

        public static string EMPTY_ARCHIVE = "NOT APPLICABLE";
        public static string UNAUTHORIZED_USER = "Current user not authorized to use this application. ";
        public static string CONTACT_INFO = "Please change this text.";
        public static string LOGIN_MESSAGE = "You have logged in successfully. ";

        // Session variables
        public static string SESSION_VARIABLE_CURRENT_USER = "CURRENT_USER";
        public static string SESSION_VARIABLE_MESSAGE = "MESSAGE";
        public static string SESSION_VARIABLE_ERROR_MESSAGE = "ERROR_MESSAGE";
        public static string SESSION_VARIABLE_CURRENT_USER_NAME = "CURRENT_USER_NAME";

        // Error Messages
        public static string ERROR_MESSAGE_STUDENT_EXISTS = "Notice: This may be a duplicate student.";
        public static string ERROR_MESSAGE_BAD_LDAP_NAME = "[ERROR] ■ Specified LDAP directory does not exist";

        // Application keys from web.config
        public static string APP_SETTINGS_LDAP_SERVER_NAME = "LDAPServerName";
        public static string APP_SETTINGS_ADMIN_EMAIL = "AdministratorEmail";
        public static string APP_SETTINGS_MIS_ERROR_EMAIL = "MISWebDev@wesdschools.org";
        public static string APP_SETTINGS_EMAIL_FROM = "donotreply@wesdschools.org";
        public static string APP_SETTINGS_EMAIL_SERVER = "smtp.wesdschools.org";
        public static string APP_SETTINGS_EVENT_LOG = "EventLog";
        public static string APP_SETTINGS_APPLICATION_NAME_LONG = "NewProgramConsideration";
        public static string APP_SETTINGS_APPLICATION_NAME_SHORT = "NewProgramConsideration";
        public static string APP_SETTINGS_APPLICATION_ERROR = "Please change this text";

        static Constants()
        {
            ValidUser = false;
        }

        public static int COMMENT_TYPE_GENERAL = 0;
        public static int COMMENT_TYPE_INFO = 1;
        public static int COMMENT_TYPE_STAFF = 2;
        public static int COMMENT_TYPE_LINE_ITEM = 3;
        public static int COMMENT_TYPE_ALL = 99;

    }
}