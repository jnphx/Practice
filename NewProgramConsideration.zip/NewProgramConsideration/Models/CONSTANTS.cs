﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class CONSTANTS
    {
        public const string ROLE_ADMIN = "Admin";
        public const string WEB_APP_NAME = "NewProgramConsideration";

        public const int ROLE_ADMIN_ID = 1;
        public const int ROLE_BUDGET_FINANCE_ID = 2;

#if DEBUG
        //public const int CATEGORY_SCHOOL_PROGRAM_ID = 16;        
#else
        //public const int CATEGORY_LOCATION_SCHOOL_PROGRAM_ID = 38;
#endif
        //public const string WORKFLOW_STEP_NEW = "NEW";
        //public const string WORKFLOW_STEP_LOCATION_APPROVAL = "LOCATION_APPROVAL";
        //public const string WORKFLOW_STEP_NOTIFICATION_REVIEW = "NOTIFICATION_REVIEW";
        //public const string WORKFLOW_STEP_FIELD_REVIEW_DETERMINATION = "FIELD_REVIEW_DETERMINATION";
        //public const string WORKFLOW_STEP_FIELD_REVIEW_PENDING = "FIELD_REVIEW_PENDING";
        //public const string WORKFLOW_STEP_BUDGET_FINANCE_APPROVAL_WITH_FIELD_REVIEW = "BUDGET_FINANCE_APPROVAL_WITH_FIELD_REVIEW";
        //public const string WORKFLOW_STEP_BUDGET_FINANCE_APPROVAL = "BUDGET_FINANCE_APPROVAL";
        //public const string WORKFLOW_STEP_BUDGET_TRANSFER = "BUDGET_TRANSFER";
        //public const string WORKFLOW_STEP_APPROVED = "APPROVED";
        //public const string WORKFLOW_STEP_REJECTED = "REJECTED";
        //public const string WORKFLOW_STEP_CANCELED = "CANCELED";
        //public const string WORKFLOW_STEP_ARCHIVED = "ARCHIVED";

        //public const string DATA_VALUE_CONFIG_NAME_ACTIVE_DATA_CONFIG = "Active Data Config";
        //public const string DATA_VALUE_CONFIG_NAME_ARCHIVE_DATA_CONFIG = "Archive Data Config";

        public static string CONTACT_INFO = "Please contact a representative of " + CONSTANTS.WEB_APP_NAME + " if you need access to this application. ";
        public static string UNAUTHORIZED_USER = "Current user not authorized to use this application. ";
        public static string LOGIN_MESSAGE = "You have logged in successfully. ";
        public static string SESSION_VARIABLE_MESSAGE = "MESSAGE";
        public static string SESSION_VARIABLE_CURRENT_USER = "CURRENT_USER";

        public const string DEVELOPER_EMAIL = "miswebdev@wesdschools.org";


#if DEBUG
        //public static string BUDGET_REQUEST_URL = "https://apps.wesdschools.org/budgetrequesttest/";
        public static string BUDGET_REQUEST_URL = "https://apps.wesdschools.org/assessmentstest/";
#else
        public static string BUDGET_REQUEST_URL = "https://apps.wesdschools.org/assessments/";
#endif
    }
}
