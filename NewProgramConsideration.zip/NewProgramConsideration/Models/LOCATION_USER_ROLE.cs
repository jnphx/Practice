﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class LOCATION_USER_ROLE
    {
        [Key]
        public int LOCATION_USER_ROLE_ID { get; set; }
        public int APP_USER_ID { get; set; }
        public virtual APP_USER APP_USER { get; set; }
        public int LOCATION_ID { get; set; }
        public virtual LOCATION LOCATION { get; set; }
        public int USER_ROLE_ID { get; set; }
        public virtual USER_ROLE USER_ROLE { get; set; }
    }
}