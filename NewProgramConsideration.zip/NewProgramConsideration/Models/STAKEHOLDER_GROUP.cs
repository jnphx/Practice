﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class STAKEHOLDER_GROUP
    {
        [Key]
        [DisplayName("Stakeholder Group ID")]
        public int STAKEHOLDER_GROUP_ID { get; set; }

        [DisplayName("Stakeholder Group Names")]
        public string STAKEHOLDER_GROUP_NAME { get; set; }

        [DisplayName("Impact Description")]
        public string STAKEHOLDER_GROUP_IMPACT_DESCRIPTION { get; set; }

        public virtual ICollection<AFFECTED_STAKEHOLDER> AFFECTED_STAKEHOLDERS {get; set; }
    }
}