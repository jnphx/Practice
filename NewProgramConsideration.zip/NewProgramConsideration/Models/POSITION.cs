﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class POSITION
    {
        [Key]
        [DisplayName("POSITION ID")]
        public int POSITION_ID { get; set; }

        [DisplayName("POSITION_NAME")]
        public string POSITION_NAME { get; set; }


    }
}