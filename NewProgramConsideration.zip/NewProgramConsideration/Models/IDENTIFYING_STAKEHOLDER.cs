﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class IDENTIFYING_STAKEHOLDER
    {
        [Key]
        [DisplayName("IDENTIFYING STAKEHOLDER ID")]
        public int IDENTIFYING_STAKEHOLDER_ID { get; set; }
        public int PROGRAM_CONSIDERATION_ID { get; set; }
        public virtual PROGRAM_CONSIDERATION PROGRAM_CONSIDERATION { get; set; }
        public int APP_USER_ID { get; set; }
        public virtual APP_USER APP_USER { get; set; }
    }
}