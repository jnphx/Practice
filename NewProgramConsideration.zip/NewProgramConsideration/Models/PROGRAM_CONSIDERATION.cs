﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class PROGRAM_CONSIDERATION
    {
        [Key]
        [DisplayName("Program Consideration ID")]
        public int PROGRAM_CONSIDERATION_ID { get; set; }

        [DisplayName("School/Dept Requestor")]
        public int SCHOOL_DEPT_REQUESTOR_ID { get; set; }
        public virtual LOCATION SCHOOL_DEPT_REQUESTOR { get; set; }

        [DisplayName("Submit Date")] //Added because 
        public DateTime? SUBMIT_DATE { get; set; }

        [DisplayName("OPENING CONTEXT")]
        public string OPENING_CONTEXT { get; set; }

        [DisplayName("IDENTIFIED NEED")]
        public string IDENTIFIED_NEED { get; set; }

        [DisplayName("ANTICIPATED OUTCOME")]
        public string ANTICIPATED_OUTCOME { get; set; }

        [DisplayName("ALTERNATIVE OPTION")]
        public string ALTERNATIVE_OPTION { get; set; }

        [DisplayName("DOCUMENTATION")]
        public string DOCUMENTATION { get; set; }

        [DisplayName("AVAIL FUNDS")]
        public string AVAIL_FUNDS { get; set; }

        [DisplayName("Simlar Program")]
        public string SIMILAR_PROGRAM { get; set; }

        [DisplayName("DISPLACED PROGRAM")]
        public string DISPLACED_PROGRAM { get; set; }

        [DisplayName("EXPANSION")]
        public string EXPANSION { get; set; }

        [DisplayName("COMPATIBILITY")]
        public string COMPATIBILITY { get; set; }

        [DisplayName("HAS PRINCIPAL SUPPORT")]
        public string HAS_PRINCIPAL_SUPPORT { get; set; }

        [DisplayName("HAS CAPITAL PROJECT SUPPORT")]
        public string HAS_CAPITAL_PROJECT_SUPPORT { get; set; }

        [DisplayName("HAS TRANSPORTATION SUPPORT")]
        public string HAS_TRANSPORTATION_SUPPORT { get; set; }

        [DisplayName("HAS MIS SUPPORT")]
        public string HAS_MIS_SUPPORT { get; set; }

        [DisplayName("HAS ACADEMIC SERVICES SUPPORT")]
        public string HAS_ACADEMIC_SERVICES_SUPPORT { get; set; }

        [DisplayName("HAS NUTRITION SERVICES SUPPORT")]
        public string HAS_NUTRITION_SERVICES_SUPPORT { get; set; }

        [DisplayName("Need Explanation")]
        public string NEED_EXPLANATION { get; set; }

        [DisplayName("Benefit Explanation")]
        public string BENEFIT_EXPLANATION { get; set; }

        [DisplayName("Is Deleted")]
        public bool IS_DELETED { get; set; }

        [DisplayName("Affected Stakeholders")]
        public virtual ICollection<AFFECTED_STAKEHOLDER> AFFECTED_STAKEHOLDERS { get; set; }

        [DisplayName("Identifying Stakeholders")]
        public virtual ICollection<APP_USER> IDENTIFYING_STAKEHOLDERS { get; set; }

        [DisplayName("PROGRAM ID")]
        public int PROGRAM_ID { get; set; }
        public virtual PROGRAM PROGRAM { get; set; }

        [DisplayName("BUDGET ID")]
        public int BUDGET_ID { get; set; }
        public virtual BUDGET BUDGET { get; set; }

        [DisplayName("Locations using program")]
        public virtual List<LOCATION_USING_PROGRAM> LOCATIONS_USING_PROGRAM { get; set; }

        [DisplayName("Dependencies for Implementation")]
        public string DEPENDENCIES { get; set; }

        [DisplayName("Risks to Implementation")]
        public string RISKS { get; set; }

        [DisplayName("APP USER ID")]
        public int APP_USER_ID { get; set; }
        public virtual APP_USER INITIATOR { get; set; }
    }
}