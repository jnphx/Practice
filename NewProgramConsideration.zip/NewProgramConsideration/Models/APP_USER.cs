﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class APP_USER
    {
        [Key]
        public int APP_USER_ID { get; set; }

        [Required]
        [DisplayName("User Name")]
        public string APP_USER_NAME { get; set; }

        [DisplayName("First Name")]
        public string FIRST_NAME { get; set; }

        [DisplayName("Last Name")]
        public string LAST_NAME { get; set; }

        [DisplayName("Email")]
        public string EMAIL { get; set; }

        [DisplayName("Position")]
        public int POSITION_ID { get; set; }
        public virtual POSITION POSITION { get; set; }

        [DisplayName("Is Active?")]
        public bool IS_ACTIVE { get; set; }

        [DisplayName("Location Roles")]
        public virtual IList<LOCATION_USER_ROLE> LOCATION_USER_ROLES { get; set; }
        public virtual ICollection<IDENTIFYING_STAKEHOLDER> IDENTIFYING_STAKEHOLDERS { get; set; }

        public string FullName
        {
            get { return FIRST_NAME + " " + LAST_NAME; }
        }
    }
}