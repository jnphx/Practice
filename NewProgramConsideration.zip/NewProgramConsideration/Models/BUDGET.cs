﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class BUDGET
    {
        public BUDGET()
        {
            //Initialize new programs as Cost Increase
            COST_INCREASE = true;
        }

        [Key]
        [DisplayName("BUDGET ID")]
        public int BUDGET_ID { get; set; }

        [DisplayName("Funding Source")]
        public string FUNDING_SOURCE { get; set; }

        [DisplayName("Change to overall cost")]
        public bool COST_INCREASE { get; set; }

        [DisplayName("Startup Costs")]
        public decimal START_UP_COSTS { get; set; }

        [DisplayName("Startup Details")]
        public string START_UP_DETAILS { get; set; }

        [DisplayName("Recurring Costs")]
        public decimal RECURRING_COSTS { get; set; }

        [DisplayName("Recurring Details")]
        public string RECURRING_DETAILS { get; set; }

        [DisplayName("Implementation Costs")]
        public decimal IMPLEMENTATIONS_COSTS { get; set; }

        [DisplayName("IS ONGOING COST")]
        public bool IS_ONGOING_COST { get; set; }

        [DisplayName("ONGOING COST")]
        public decimal ONGOING_COST { get; set; }

        [DisplayName("IS BUDGET AVAIL")]
        public bool IS_BUDGET_AVAIL { get; set; }

        [DisplayName("BUDGET AVAIL DETAIL")]
        public string BUDGET_AVAIL_DETAIL { get; set; }

        [DisplayName("IS ADD STAFF REQD")]
        public bool IS_ADD_STAFF_REQD { get; set; }

        [DisplayName("ADD STAFF DETAIL")]
        public string ADD_STAFF_DETAIL { get; set; }

        [DisplayName("ADD STAFF COST")]
        public decimal ADD_STAFF_COST { get; set; }

        [DisplayName("IS PROF DEV REQD")]
        public bool IS_PROF_DEV_REQD { get; set; }

        [DisplayName("PROF DEV DETAIL")]
        public string PROF_DEV_DETAIL { get; set; }

        [DisplayName("PROF DEV COST")]
        public decimal PROF_DEV_COST { get; set; }

        [DisplayName("IS ADD INSTRUCT REQD")]
        public bool IS_ADD_INSTRUCT_REQD { get; set; }

        [DisplayName("ADD INSTRUCT DETAIL")]
        public string ADD_INSTRUCT_DETAIL { get; set; }

        [DisplayName("ADD INSTRUCT COST")]
        public decimal ADD_INSTRUCT_COST { get; set; }

        [DisplayName("IS ADD EQUIP REQD")]
        public bool IS_ADD_EQUIP_REQD { get; set; }

        [DisplayName("ADD EQUIP DETAIL")]
        public string ADD_EQUIP_DETAIL { get; set; }

        [DisplayName("ADD EQUIP COST")]
        public decimal ADD_EQUIP_COST { get; set; }

        [DisplayName("IS SITE RENOVATION REQD")]
        public bool IS_SITE_RENOVATION_REQD { get; set; }

        [DisplayName("SITE RENOVATION DETAIL")]
        public string SITE_RENOVATION_DETAIL { get; set; }

        [DisplayName("SITE RENOVATION COST")]
        public decimal SITE_RENOVATION_COST { get; set; }

        [DisplayName("Budget spreadsheet")]
        public string SPREADSHEET_PATH { get; set; }

        [DisplayName("Budget concerns")]
        public string CONCERNS { get; set; }

        [DisplayName("PROGRAM CONSIDERATION ID")]
        public int PROGRAM_CONSIDERATION_ID { get; set; }
        [Required]
        public virtual PROGRAM_CONSIDERATION PROGRAM_CONSIDERATION { get; set; }
    }
}