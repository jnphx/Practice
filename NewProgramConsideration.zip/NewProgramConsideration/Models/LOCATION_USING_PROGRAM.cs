﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class LOCATION_USING_PROGRAM
    {
        [Key]
        public int LOCATION_USING_PROGRAM_ID { get; set; }

        public int LOCATION_ID { get; set; }
        public virtual LOCATION LOCATION {get; set; }
        public int PROGRAM_CONSIDERATION_ID { get; set; }
        public virtual PROGRAM_CONSIDERATION PROGRAM_CONSIDERATION { get; set; }


    }
}