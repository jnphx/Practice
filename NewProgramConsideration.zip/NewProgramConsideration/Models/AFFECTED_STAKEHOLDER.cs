﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class AFFECTED_STAKEHOLDER
    {
        [Key]
        [DisplayName("AFFECTED STAKEHOLDER ID")]
        public int AFFECTED_STAKEHOLDER_ID { get; set; }
        public int PROGRAM_CONSIDERATION_ID { get; set; }
        public virtual PROGRAM_CONSIDERATION PROGRAM_CONSIDERATION { get; set; }
        public int STAKEHOLDER_GROUP_ID { get; set; }
        public virtual STAKEHOLDER_GROUP STAKEHOLDER_GROUP { get; set; }
    }
}