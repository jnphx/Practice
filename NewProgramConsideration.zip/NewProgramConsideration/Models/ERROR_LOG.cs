﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class ERROR_LOG
    {
        [Key]
        public int ERROR_LOG_ID { get; set; }
        public string CONTROLLER { get; set; }
        public string ACTION { get; set; }
        public int? APP_USER_ID { get; set; }
        public virtual APP_USER APP_USER { get; set; }
        public string MESSAGE { get; set; }
        public string DATA { get; set; }
        public string INNER_EXCEPTION { get; set; }
        public string HRESULT { get; set; }
        public string SOURCE { get; set; }
        public string STACK_TRACE { get; set; }
        public string BROWSER { get; set; }
    }
}