﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class PROGRAM
    {
        [Key]
        [DisplayName("PROGRAM ID")]
        public int PROGRAM_ID { get; set; }

        [DisplayName("Location/Department")]
        public int LOCATION_ID { get; set; }
        public virtual LOCATION LOCATION { get; set; }

        [DisplayName("Email")]
        public string EMAIL { get; set; }

        [DisplayName("Phone")]
        public string PHONE { get; set; }

        [DisplayName("Contact Name")]
        public string CONTACT { get; set; }

        [DisplayName("Program Name")]
        public string PROGRAM_NAME { get; set; }

        [DisplayName("Program Description")]
        public string PROGRAM_DESCRIPTION { get; set; }

        [DisplayName("# impacted students")]
        public int NUM_STUDENTS { get; set; }

        [DisplayName("# impacted staff")]
        public int NUM_STAFF { get; set; }

        [DisplayName("Proposed Implementation")]
        public string PROPOSED_IMPLEMENTATION { get; set; }

        [DisplayName("PROGRAM CONSIDERATION ID")]
        public int PROGRAM_CONSIDERATION_ID { get; set; }
        [Required]
        public virtual PROGRAM_CONSIDERATION PROGRAM_CONSIDERATION { get; set; }

        [DisplayName("Completed By")]
        public DateTime? COMPLETED_BY { get; set; }

        [DisplayName("Document")]
        public string DOCUMENT { get; set; }
    }
}