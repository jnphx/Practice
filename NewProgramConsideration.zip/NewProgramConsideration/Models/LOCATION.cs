﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Models
{
    public class LOCATION
    {
        [Key]
        public int LOCATION_ID { get; set; }

        [Required]
        [DisplayName("Location Name")]
        public string LOCATION_NAME { get; set; }

        [DisplayName("Location Code")]
        public string LOCATION_CODE { get; set; }

        [DisplayName("School Code")]
        public string SCHOOL_CODE { get; set; }
    }
}