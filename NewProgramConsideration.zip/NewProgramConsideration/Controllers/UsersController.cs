﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using NewProgramConsideration.Infrastructure;
using NewProgramConsideration.Infrastructure.Abstract;
using NewProgramConsideration.Models;
using NewProgramConsideration.ViewModels;

namespace NewProgramConsideration.Controllers
{
    public class UsersController : Controller
    {
        private DataContext db = new DataContext();
        private IRepository repository;

        // GET: Users
        public ActionResult Index()
        {
            return View(db.APP_USERS.ToList());
        }

        // GET: Users/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            APP_USER aPP_USER = db.APP_USERS.Find(id);
            if (aPP_USER == null)
            {
                return HttpNotFound();
            }
            return View(aPP_USER);
        }

        // GET: Users/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Users/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "APP_USER_ID,APP_USER_NAME,FIRST_NAME,LAST_NAME,EMAIL,IS_ACTIVE")] APP_USER aPP_USER)
        {
            if (ModelState.IsValid)
            {
                db.APP_USERS.Add(aPP_USER);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(aPP_USER);
        }

        //// GET: Users/Edit/5
        //public ActionResult Edit(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    APP_USER aPP_USER = db.APP_USERS.Find(id);
        //    if (aPP_USER == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(aPP_USER);
        //}

        // GET: UserAdmin/Edit/5
        [AuthorizeRedirect(Roles = "Admin")]
        public ActionResult Edit(int id = 0)
        {
            UserViewModel user = new UserViewModel();

            if (id == 0)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            user.theUser = repository.GetUserByID(id);
            if (user.theUser == null)
            {
                return HttpNotFound();
            }
            user.DdlLocations = new SelectList(repository.LOCATIONS, "LOCATION_ID", "NAME");
            user.ChkLocations = new SelectList(repository.LOCATIONS.Where(w => !string.IsNullOrEmpty(w.SCHOOL_CODE)), "SCHOOL_CODE", "NAME");
            user.DdlUserRoles = new SelectList(repository.USER_ROLES, "USER_ROLE_ID", "NAME");

            //Get Permissions
            //user = GetReportPermissions(user);

            return View(user);
        }

        // POST: Users/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "APP_USER_ID,APP_USER_NAME,FIRST_NAME,LAST_NAME,EMAIL,IS_ACTIVE")] APP_USER aPP_USER)
        {
            if (ModelState.IsValid)
            {
                db.Entry(aPP_USER).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(aPP_USER);
        }

        // GET: Users/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            APP_USER aPP_USER = db.APP_USERS.Find(id);
            if (aPP_USER == null)
            {
                return HttpNotFound();
            }
            return View(aPP_USER);
        }

        // POST: Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            APP_USER aPP_USER = db.APP_USERS.Find(id);
            db.APP_USERS.Remove(aPP_USER);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
