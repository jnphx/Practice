﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using NewProgramConsideration.Infrastructure;
using NewProgramConsideration.Infrastructure.Abstract;
using NewProgramConsideration.Models;
using NewProgramConsideration.ViewModels;
using System.IO;

namespace NewProgramConsideration.Controllers
{
    public class PROGRAM_CONSIDERATIONController : Controller
    {
        private DataContext db = new DataContext();
        private IRepository repository;
        APP_USER userUser;

        public PROGRAM_CONSIDERATIONController(IRepository iRepository)
        {
            this.repository = iRepository;
        }

        public ActionResult Create(int id = 0, bool isEdit = false)
        {
            ProgramConsiderationViewModel consid = new ProgramConsiderationViewModel();
            if (id != 0)
            {
                consid.theProgramConsideration = repository.GetProgramConsideration(id);
            }
            else
            {
                consid.theProgramConsideration = new PROGRAM_CONSIDERATION();
                consid.theProgramConsideration.AFFECTED_STAKEHOLDERS = new Collection<AFFECTED_STAKEHOLDER>();
                consid.theProgramConsideration.LOCATIONS_USING_PROGRAM = new List<LOCATION_USING_PROGRAM>();
                consid.theProgramConsideration.BUDGET = new BUDGET();
                consid.theProgramConsideration.PROGRAM = new PROGRAM();
            }

            SetConsidViewModelProperties(consid);
            consid.isEdit = isEdit;
            if (consid.isEdit)
            {
                consid.isReadOnly = false;
            }
            else
            {
                if (id == 0)
                {
                    consid.isReadOnly = false;
                }
                else
                {
                    consid.isReadOnly = true;
                }
            }
            consid.canUploadFile = true;

            //request.userRoles = userUser.LOCATION_PERMISSIONS.Select(s => s.USER_PERMISSION).ToList();

            /* JN
            if (Session["ActionRequired"] == null)
            {
                GetApprovalReviewRequests(request);
                Session["ActionRequired"] = request.reviewList.Count();
                Session["ApprovalRequired"] = request.approvalList.Count();
            }

            ViewBag.ActionRequired = Convert.ToInt16(Session["ActionRequired"].ToString());
            ViewBag.ApprovalRequired = Convert.ToInt16(Session["ApprovalRequired"]);
            */

            return View(consid);
        }

        public ProgramConsiderationViewModel SetConsidViewModelProperties(ProgramConsiderationViewModel consid)
        {
            PopulateAffectedStakeholderGroups(consid);
            consid.DdlLocations = new SelectList(repository.LOCATIONS, "LOCATION_ID", "LOCATION_NAME");
            consid.DdlStakeholderGroups = new SelectList(repository.STAKEHOLDER_GROUPS, "STAKEHOLDER_GROUP_ID", "STAKEHOLDER_GROUP_NAME");

            return consid;
        }


        public ActionResult DeleteLocationUsing(int LocationUsingId)
        {
            return View("ProgramContext");
        }
        private ProgramConsiderationViewModel GetConsid()
        {
            if (Session["Consid"] == null)
            {
                ProgramConsiderationViewModel consid = new ProgramConsiderationViewModel();
                consid.theProgramConsideration = new PROGRAM_CONSIDERATION();
                consid.theProgramConsideration.AFFECTED_STAKEHOLDERS = new Collection<AFFECTED_STAKEHOLDER>();
                consid.theProgramConsideration.LOCATIONS_USING_PROGRAM = new List<LOCATION_USING_PROGRAM>();
                consid.theProgramConsideration.BUDGET = new BUDGET();
                consid.theProgramConsideration.PROGRAM = new PROGRAM();
                Session["Consid"] = consid;
            }
            return (ProgramConsiderationViewModel)Session["Consid"];
        }

        private void RemoveConsid()
        {
            Session.Remove("Consid");
        }

        // GET: PROGRAM_CONSIDERATION
        public ActionResult Index()
        {
            ProgramConsiderationViewModel vm = new ProgramConsiderationViewModel();

            return View(vm);
        }

        // GET: PROGRAM_CONSIDERATION
        public ActionResult ViewConsideration(int id)
        {
            ProgramConsiderationViewModel progConsid = new ProgramConsiderationViewModel();
            progConsid.theProgramConsideration = repository.GetProgramConsideration(id);
            //if (progConsid.theProgramConsideration == null || progConsid.theProgramConsideration.WORKFLOW == null)
            if (progConsid.theProgramConsideration == null)
            {
                return View("InvalidRequest");
            }
            InitProgramContactInfo(progConsid);
            /*progConsid.theCurrentWorkflowStep = wfRepository.GetCurrentWorkflowStep(progConsid.theRequest.WORKFLOW_ID);

            ViewBag.WorkflowStatus = progConsid.theCurrentWorkflowStep.WORKFLOW_STEP_NAME;
            progConsid.Status = progConsid.theCurrentWorkflowStep.WORKFLOW_STEP_NAME;
            SetRequestViewModelProperties(progConsid);
            progConsid.isReadOnly = true;
            progConsid.userRoles = userUser.LOCATION_PERMISSIONS.Select(s => s.USER_PERMISSION).ToList();
            progConsid.userCategories = userUser.CATEGORIES.ToList();
            if (progConsid.theRequest.USER_ID == userUser.USER_ID)
            {
                progConsid.canUpdateBudgetInformation = true;
            }

            progConsid.DdlDecisions = new SelectList(repository.DECISIONS, "DECISION_ID", "DECISION_NAME");
            repository.DetermineUserAccess(userUser, progConsid, progConsid.theCurrentWorkflowStep);

            if (Session["ActionRequired"] == null)
            {
                GetApprovalReviewRequests(progConsid);
                Session["ActionRequired"] = progConsid.reviewList.Count();
                Session["ApprovalRequired"] = progConsid.approvalList.Count();
            }

            ViewBag.ActionRequired = Convert.ToInt16(Session["ActionRequired"].ToString());
            ViewBag.ApprovalRequired = Convert.ToInt16(Session["ApprovalRequired"]);
            */
            return View(progConsid);

        }

        // GET: PROGRAM_CONSIDERATION/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PROGRAM_CONSIDERATION pROGRAM_CONSIDERATION = db.PROGRAM_CONSIDERATIONS.Find(id);
            if (pROGRAM_CONSIDERATION == null)
            {
                return HttpNotFound();
            }
            return View(pROGRAM_CONSIDERATION);
        }

        private void PopulateAffectedStakeholderGroups(ProgramConsiderationViewModel progConsid)
        {
            var allStakeholderGroups = db.STAKEHOLDER_GROUPS;
            var ProgConsidStakeholders = new HashSet<int>(progConsid.theProgramConsideration.AFFECTED_STAKEHOLDERS.Select(g => g.STAKEHOLDER_GROUP_ID));
            var viewModel = new List<ProgramConsiderationViewModel.AffectedStakeHolderData>();
            foreach (var stakeholderGroup in allStakeholderGroups)
            {
                viewModel.Add(new ProgramConsiderationViewModel.AffectedStakeHolderData
                {
                    STAKEHOLDER_GROUP_ID = stakeholderGroup.STAKEHOLDER_GROUP_ID,
                    STAKEHOLDER_GROUP_NAME = stakeholderGroup.STAKEHOLDER_GROUP_NAME,
                    STAKEHOLDER_GROUP_IMPACT_DESCRIPTION = stakeholderGroup.STAKEHOLDER_GROUP_IMPACT_DESCRIPTION,
                    Affected = ProgConsidStakeholders.Contains(stakeholderGroup.STAKEHOLDER_GROUP_ID)
                });
            }
            ViewBag.StakeholderGroups = viewModel;
        }

        private void InitBasicProgramInfo(ProgramConsiderationViewModel consid)
        {
            PopulateAffectedStakeholderGroups(consid);
        }
        private void InitProgramContactInfo(ProgramConsiderationViewModel consid)
        {
            consid.DdlLocations = new SelectList(repository.LOCATIONS, "LOCATION_ID", "LOCATION_NAME");
            consid.DdlStakeholderGroups = new SelectList(repository.STAKEHOLDER_GROUPS, "STAKEHOLDER_GROUP_ID", "STAKEHOLDER_GROUP_NAME");
        }

        private void InitProgramContext(ProgramConsiderationViewModel consid)
        {
            //consid.DdlLocations = new SelectList(repository.LOCATIONS, "LOCATION_ID", "LOCATION_NAME");
        }

        // GET: PROGRAM_CONSIDERATION/ProgramContactInfo
        public ActionResult ProgramContactInfo()
        {
            ProgramConsiderationViewModel consid = GetConsid();
            InitProgramContactInfo(consid);
            return View(consid);
        }

        // POST: PROGRAM_CONSIDERATION/ProgramContactInfo
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ProgramContactInfo(ProgramConsiderationViewModel data, string prevBtn, string nextBtn, string[] selectedStakeholderGroups)
        {
            if (nextBtn != null)
            {
                //if (ModelState.IsValid)
                //{
                ProgramConsiderationViewModel obj = GetConsid();
                obj.theProgramConsideration.SCHOOL_DEPT_REQUESTOR_ID = data.theProgramConsideration.SCHOOL_DEPT_REQUESTOR_ID;
                obj.theProgramConsideration.PROGRAM.CONTACT = data.theProgramConsideration.PROGRAM.CONTACT;
                obj.theProgramConsideration.PROGRAM.LOCATION_ID = data.theProgramConsideration.PROGRAM.LOCATION_ID;
                obj.theProgramConsideration.PROGRAM.EMAIL = data.theProgramConsideration.PROGRAM.EMAIL;
                obj.theProgramConsideration.PROGRAM.PROGRAM_NAME = data.theProgramConsideration.PROGRAM.PROGRAM_NAME;
                obj.theProgramConsideration.PROGRAM.NUM_STAFF = data.theProgramConsideration.PROGRAM.NUM_STAFF;
                obj.theProgramConsideration.PROGRAM.NUM_STUDENTS = data.theProgramConsideration.PROGRAM.NUM_STUDENTS;
                UpdateProjConsidStakeholderGroups(selectedStakeholderGroups, obj);
                InitBasicProgramInfo(obj);
                return View("BasicProgramInfo", obj);
                //}
            }
            return View();
        }

        // POST: PROGRAM_CONSIDERATION/BasicProgramInfo
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BasicProgramInfo(ProgramConsiderationViewModel data, string prevBtn, string nextBtn, string[] selectedStakeholderGroups)
        {
            ProgramConsiderationViewModel obj = GetConsid();
            if (prevBtn != null)
            {
                InitProgramContactInfo(obj);
                return View("ProgramContactInfo", obj);
            }
            if (nextBtn != null)
            {
                //TODO: how to check if data was valid before adding, if (ModelState.IsValid)
                //{
                obj.theProgramConsideration.PROGRAM.PROGRAM_NAME = data.theProgramConsideration.PROGRAM.PROGRAM_NAME;
                obj.theProgramConsideration.PROGRAM.NUM_STAFF = data.theProgramConsideration.PROGRAM.NUM_STAFF;
                obj.theProgramConsideration.PROGRAM.NUM_STUDENTS = data.theProgramConsideration.PROGRAM.NUM_STUDENTS;
                UpdateProjConsidStakeholderGroups(selectedStakeholderGroups, obj);
                InitProgramContext(obj);
                return View("ProgramContext", obj);
                //}
            }
            return View();
        }

        private void UpdateProjConsidStakeholderGroups(string[] selectedStakeholderGroups, ProgramConsiderationViewModel projConsid)
        {
            if (selectedStakeholderGroups == null)
            {
                projConsid.theProgramConsideration.AFFECTED_STAKEHOLDERS = new List<AFFECTED_STAKEHOLDER>();
                return;
            }

            var selectedStakeholders = new HashSet<string>(selectedStakeholderGroups);
            var projConsidAffectedStakeholders = new HashSet<int>
                    (projConsid.theProgramConsideration.AFFECTED_STAKEHOLDERS.Select(c => c.STAKEHOLDER_GROUP_ID));
            foreach (var stakeholderGroup in db.STAKEHOLDER_GROUPS)
            {
                if (selectedStakeholders.Contains(stakeholderGroup.STAKEHOLDER_GROUP_ID.ToString()))
                {
                    if (!projConsidAffectedStakeholders.Contains(stakeholderGroup.STAKEHOLDER_GROUP_ID))
                    {
                        projConsid.theProgramConsideration.AFFECTED_STAKEHOLDERS.Add(new AFFECTED_STAKEHOLDER { STAKEHOLDER_GROUP_ID = stakeholderGroup.STAKEHOLDER_GROUP_ID });
                    }
                }
                else
                {
                    if (projConsidAffectedStakeholders.Contains(stakeholderGroup.STAKEHOLDER_GROUP_ID))
                    {
                        var stakeHolderToRemove = projConsid.theProgramConsideration.AFFECTED_STAKEHOLDERS.FirstOrDefault(s => s.STAKEHOLDER_GROUP_ID == stakeholderGroup.STAKEHOLDER_GROUP_ID);
                        projConsid.theProgramConsideration.AFFECTED_STAKEHOLDERS.Remove(stakeHolderToRemove);
                    }
                }
            }
        }

        // POST: PROGRAM_CONSIDERATION/ProgramContext
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ProgramContext(ProgramConsiderationViewModel data, string prevBtn, string nextBtn)
        {
            ProgramConsiderationViewModel obj = GetConsid();
            if (prevBtn != null)
            {
                InitBasicProgramInfo(obj);
                return View("BasicProgramInfo", obj);
            }
            if (nextBtn != null)
            {
                obj.theProgramConsideration.NEED_EXPLANATION = data.theProgramConsideration.NEED_EXPLANATION;
                List<LOCATION_USING_PROGRAM> newLocationUsingPrograms = new List<LOCATION_USING_PROGRAM>();
                if (data.locationsSelected != null && data.locationsSelected.Count > 0)
                {
                    for (int i = 0; i < data.locationsSelected.Count; i++)
                    {
                        if (data.locationsSelected[i] != 0)
                        {
                            LOCATION_USING_PROGRAM locationAdd = new LOCATION_USING_PROGRAM();
                            // Grabbing Location
                            locationAdd.LOCATION = repository.GetLocation(data.locationsSelected[i]);

                            if (!obj.theProgramConsideration.LOCATIONS_USING_PROGRAM.Contains(locationAdd))
                            {
                                obj.theProgramConsideration.LOCATIONS_USING_PROGRAM.Add(locationAdd);
                                newLocationUsingPrograms.Add(locationAdd);
                            }
                        }
                    }
                }

                //remove existing location permissions
                var locationsToRemove = new List<LOCATION_USING_PROGRAM>();
                if (newLocationUsingPrograms.Count > 0)
                {
                    locationsToRemove = obj.theProgramConsideration.LOCATIONS_USING_PROGRAM.Except(newLocationUsingPrograms).ToList();
                }
                else
                {
                    locationsToRemove = obj.theProgramConsideration.LOCATIONS_USING_PROGRAM;
                }

                foreach (var loc in locationsToRemove)
                {
                    obj.theProgramConsideration.LOCATIONS_USING_PROGRAM.Remove(loc);
                }

                return View("Funding", obj);

                //End

            }
            return View("", obj);
        }

        // POST: PROGRAM_CONSIDERATION/Funding
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Funding(ProgramConsiderationViewModel data, string prevBtn, string nextBtn, HttpPostedFileBase budgetfile)
        {
            ProgramConsiderationViewModel obj = GetConsid();
            if (prevBtn != null)
            {
                InitProgramContactInfo(obj);
                return View("ProgramContext", obj);
            }
            if (nextBtn != null)
            {
                obj.theProgramConsideration.BUDGET.FUNDING_SOURCE = data.theProgramConsideration.BUDGET.FUNDING_SOURCE;
                obj.theProgramConsideration.BUDGET.COST_INCREASE = data.theProgramConsideration.BUDGET.COST_INCREASE;
                obj.theProgramConsideration.BUDGET.START_UP_DETAILS = data.theProgramConsideration.BUDGET.START_UP_DETAILS;
                obj.theProgramConsideration.BUDGET.RECURRING_DETAILS = data.theProgramConsideration.BUDGET.RECURRING_DETAILS;
                obj.theProgramConsideration.BUDGET.CONCERNS = data.theProgramConsideration.BUDGET.CONCERNS;
                //Save budget spreadsheet
                //TODO: save spreadsheet to location once Program Consideration ID is set
                //SaveBudgetSpreadsheet(obj, budgetfile);
                return View("Implementation", obj);
            }
            return View();
        }

        private void SaveBudgetSpreadsheet(ProgramConsiderationViewModel consid, HttpPostedFileBase file)
        {
            if (file != null)
            {
                try
                {
                    if (file.ContentLength > 0 && file.ContentLength <= 20971520 && IsValidFileType(file)) //&& file.FileName.Contains("pdf"))
                    {
                        string subpath = "~/App_Data/Documentation/" + consid.theProgramConsideration.PROGRAM.LOCATION.LOCATION_NAME + "/" + consid.theProgramConsideration.PROGRAM_CONSIDERATION_ID + "/";

                        //check directory has location folder, if not create one
                        string locationFolder = Path.Combine(Server.MapPath("~/App_Data/Documentation/"), consid.theProgramConsideration.PROGRAM.LOCATION.LOCATION_NAME + "/" + consid.theProgramConsideration.PROGRAM_CONSIDERATION_ID + "/");
                        if (!Directory.Exists(locationFolder))
                        {
                            Directory.CreateDirectory(locationFolder);
                        }

                        var fileName = Path.GetFileName(file.FileName);
                        string filePath = Path.Combine(Server.MapPath(subpath), fileName);
                        file.SaveAs(filePath);
                        consid.theProgramConsideration.BUDGET.SPREADSHEET_PATH = consid.theProgramConsideration.PROGRAM.LOCATION.LOCATION_NAME + "/" + consid.theProgramConsideration.PROGRAM_CONSIDERATION_ID + "/" + fileName;
                    }
                    else
                    {
                        ModelState.AddModelError("Error", "One or more file has an invalid file type or file size is over 20MB");
                        //SetRequestViewModelProperties(request);
                        //request.isEdit = request.isEdit;
                        //return View(consid);
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("Error", "An error occured while saving the uploaded file");
                    repository.SendExceptionMail(ex, System.Web.HttpContext.Current.Request);
                }
            }
        }

        // POST: PROGRAM_CONSIDERATION/Implementation
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Implementation(ProgramConsiderationViewModel data, string prevBtn, string nextBtn)
        {
            ProgramConsiderationViewModel obj = GetConsid();
            if (prevBtn != null)
            {
                InitProgramContactInfo(obj);
                return View("Funding", obj);
            }
            if (nextBtn != null)
            {
                obj.theProgramConsideration.DEPENDENCIES = data.theProgramConsideration.DEPENDENCIES;
                obj.theProgramConsideration.RISKS = data.theProgramConsideration.RISKS;
                repository.SaveProgramConsideration(obj.theProgramConsideration);
                Session.Remove("Consid");
                return View("../Home/Index");
            }
            return View();
        }

        // GET: PROGRAM_CONSIDERATION/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PROGRAM_CONSIDERATION pROGRAM_CONSIDERATION = db.PROGRAM_CONSIDERATIONS.Find(id);
            if (pROGRAM_CONSIDERATION == null)
            {
                return HttpNotFound();
            }
            ViewBag.PROGRAM_CONSIDERATION_ID = new SelectList(db.BUDGETS, "BUDGET_ID", "START_UP_DETAILS", pROGRAM_CONSIDERATION.PROGRAM_CONSIDERATION_ID);
            ViewBag.PROGRAM_CONSIDERATION_ID = new SelectList(db.PROGRAMS, "PROGRAM_ID", "PROGRAM_NAME", pROGRAM_CONSIDERATION.PROGRAM_CONSIDERATION_ID);
            return View(pROGRAM_CONSIDERATION);
        }

        // POST: PROGRAM_CONSIDERATION/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "PROGRAM_CONSIDERATION_ID,SUBMIT_DATE,OPENING_CONTEXT,IDENTIFIED_NEED,ANTICIPATED_OUTCOME,ALTERNATIVE_OPTION,DOCUMENTATION,AVAIL_FUNDS,SIMILAR_PROGRAM,DISPLACED_PROGRAM,EXPANSION,COMPATIBILITY,HAS_PRINCIPAL_SUPPORT,HAS_CAPITAL_PROJECT_SUPPORT,HAS_TRANSPORTATION_SUPPORT,HAS_MIS_SUPPORT,HAS_ACADEMIC_SERVICES_SUPPORT,HAS_NUTRITION_SERVICES_SUPPORT,NEED_EXPLANATION,BENEFIT_EXPLANATION,IS_DELETED,PROGRAM_ID,BUDGET_ID")] PROGRAM_CONSIDERATION pROGRAM_CONSIDERATION)
        {
            if (ModelState.IsValid)
            {
                db.Entry(pROGRAM_CONSIDERATION).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.PROGRAM_CONSIDERATION_ID = new SelectList(db.BUDGETS, "BUDGET_ID", "START_UP_DETAILS", pROGRAM_CONSIDERATION.PROGRAM_CONSIDERATION_ID);
            ViewBag.PROGRAM_CONSIDERATION_ID = new SelectList(db.PROGRAMS, "PROGRAM_ID", "PROGRAM_NAME", pROGRAM_CONSIDERATION.PROGRAM_CONSIDERATION_ID);
            return View(pROGRAM_CONSIDERATION);
        }

        // GET: PROGRAM_CONSIDERATION/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PROGRAM_CONSIDERATION pROGRAM_CONSIDERATION = db.PROGRAM_CONSIDERATIONS.Find(id);
            if (pROGRAM_CONSIDERATION == null)
            {
                return HttpNotFound();
            }
            return View(pROGRAM_CONSIDERATION);
        }

        // POST: PROGRAM_CONSIDERATION/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PROGRAM_CONSIDERATION pROGRAM_CONSIDERATION = db.PROGRAM_CONSIDERATIONS.Find(id);
            db.PROGRAM_CONSIDERATIONS.Remove(pROGRAM_CONSIDERATION);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        protected bool IsValidFileType(HttpPostedFileBase file)
        {
            switch (file.ContentType)
            {
                case "image/jpeg":
                case "image/jpg":
                case "image/png":
                case "image/gif":
                case "application/pdf":
                case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                case "application/vnd.ms-excel":
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                case "application/msword":
                case "text/plain":
                    return true;
                default:
                    return false;
            }
        }

        //
        // POST: /REQUESTS/Create
        [HttpPost]
        public ActionResult Create(ProgramConsiderationViewModel consid, string Command, HttpPostedFileBase[] files)
        {
            int flag;
            string errorMsg = "At least one request type must be selected.";
            List<int> tempList = new List<int>();
            List<int> fundingTempList = new List<int>();

            switch (Command)
            {
                case "CONTINUE":
                    consid.theProgramConsideration.INITIATOR = userUser;
                    /* TODO - add workflow later
                    WORKFLOW_DEF wfDef = wfRepository.WorkflowDefs.Where(w => w.WORKFLOW_DELETED == false).FirstOrDefault();
                    WORKFLOW wf = wfRepository.CreateWorkflowFromDef(wfDef, null);

                    consid.theProgramConsideration.WORKFLOW_ID = wf.WORKFLOW_ID;
                    
                    request.theRequest.IS_COMPLETE = false;
                    request.theRequest.IS_CANCELED = false;
                    request.theRequest.IS_ACTIVE = true;
                    */
                    consid.theProgramConsideration.AFFECTED_STAKEHOLDERS = new List<AFFECTED_STAKEHOLDER>();
                    //request.theRequest.NARRATIVE = new NARRATIVE(); //placeholder created here to avoid error in creating the request
                    
                    if (Request.Params["selectedStakeholderGroups"] != null)
                    {
                        for (int i = 0; i < Request.Params.GetValues("selectedStakeholderGroups").Length; i++)
                        {
                            AFFECTED_STAKEHOLDER affectedStakeholder = new AFFECTED_STAKEHOLDER();
                            if (Int32.TryParse(Request.Params.GetValues("selectedStakeholderGroups")[i], out flag))
                            {
                                var stakeholderId = Convert.ToInt32(Request.Params.GetValues("selectedStakeholderGroups")[i]);
                                tempList.Add(stakeholderId);
                            }
                        }
                    } 

                    consid.theProgramConsideration.AFFECTED_STAKEHOLDERS = ProcessAffectedStakeholderCheckBoxes(consid.theProgramConsideration.AFFECTED_STAKEHOLDERS.ToList(), tempList);
                    try
                    {
                        if (consid.theProgramConsideration.AFFECTED_STAKEHOLDERS.Count() > 0)
                        { 
                            /* JN - special handling for Budget Request
        {
            bool isStaffingRequest = false;

            if (request.theRequest.REQUEST_TYPES.Any(w => w.REQUEST_TYPE_NAME == CONSTANTS.REQUEST_TYPE_STAFFING))
            {
                isStaffingRequest = true;
                if (!request.theRequest.REQUEST_TYPES.Any(w => w.REQUEST_TYPE_NAME == CONSTANTS.REQUEST_TYPE_CAPITAL))
                {
                    REQUEST_TYPE type = new REQUEST_TYPE();
                    type = repository.GetRequestType(CONSTANTS.REQUEST_TYPE_CAPITAL_ID);
                    request.theRequest.REQUEST_TYPES.Add(type);
                }

                if (!request.theRequest.REQUEST_TYPES.Any(w => w.REQUEST_TYPE_NAME == CONSTANTS.REQUEST_TYPE_OTHER_RESOURCE))
                {
                    REQUEST_TYPE type = new REQUEST_TYPE();
                    type = repository.GetRequestType(CONSTANTS.REQUEST_TYPE_OTHER_RESOURCE_ID);
                    request.theRequest.REQUEST_TYPES.Add(type);
                }
            }
            */

                            repository.SaveProgramConsideration(consid.theProgramConsideration);
                            /* TODO: add workflow later
                            var locationName = repository.GetLocation(request.theRequest.LOCATION_ID).LOCATION_NAME;
                            var newWorkflowName = locationName + "_" + userUser.USER_NAME + "_" + "RequestId_" + request.theRequest.REQUEST_ID;
                            wfRepository.RenameWorkflow(request.theRequest.WORKFLOW_ID, newWorkflowName);
                            */
                            return RedirectToAction("SupportingContext", new { id = consid.theProgramConsideration.PROGRAM_CONSIDERATION_ID });
                        }
                        else
                        {
                            ViewBag.LocationMsg = errorMsg;
                        }
                    }
                    catch (Exception ex)
                    {
                        repository.SendExceptionMail(ex, System.Web.HttpContext.Current.Request);
                    }

                    SetConsidViewModelProperties(consid);
/*
                    if (Session["ActionRequired"] == null)
                    {
                        GetApprovalReviewRequests(request);
                        Session["ActionRequired"] = request.reviewList.Count();
                        Session["ApprovalRequired"] = request.approvalList.Count();
                    }

                    ViewBag.ActionRequired = Convert.ToInt16(Session["ActionRequired"].ToString());
                    ViewBag.ApprovalRequired = Convert.ToInt16(Session["ApprovalRequired"]);
                    */
                    return View(consid);

                case "SAVE":
                    var requestToSave = repository.GetProgramConsideration(consid.theProgramConsideration.PROGRAM_CONSIDERATION_ID);
                    try
                    {
                        if (requestToSave.AFFECTED_STAKEHOLDERS == null)
                        {
                            requestToSave.AFFECTED_STAKEHOLDERS = new List<AFFECTED_STAKEHOLDER>();
                        }

                        //Save selectedStakeholderGroups to AFFECTED_STAKEHOLDER
                        /*
                        if (Request.Params["selectedStakeholderGroups"] != null)
                        {
                            for (int i = 0; i < Request.Params.GetValues("selectedStakeholderGroups").Length; i++)
                            {
                                REQUEST_TYPE type = new REQUEST_TYPE();
                                if (Int32.TryParse(Request.Params.GetValues("SelectedRequestTypes")[i], out flag))
                                {
                                    var typeId = Convert.ToInt32(Request.Params.GetValues("SelectedRequestTypes")[i]);
                                    tempList.Add(typeId);
                                }
                            }
                        }

                        requestToSave.REQUEST_TYPES = ProcessRequestTypeCheckBoxes(requestToSave.REQUEST_TYPES.ToList(), tempList);
                        */
/* TODO Add more fields to save here
                        if (Request.Params["SelectedFunding"] != null)
                        {
                            for (int i = 0; i < Request.Params.GetValues("SelectedFunding").Length; i++)
                            {
                                if (Int32.TryParse(Request.Params.GetValues("SelectedFunding")[i], out flag))
                                {
                                    var fundingId = Convert.ToInt32(Request.Params.GetValues("SelectedFunding")[i]);
                                    fundingTempList.Add(fundingId);
                                }
                            }
                        }
                        requestToSave.FUNDING_SOURCES = ProcessFundingSourceCheckBoxes(requestToSave.FUNDING_SOURCES.ToList(), fundingTempList);
                        repository.SaveRequest(requestToSave);

                        //address narrative items
                        if (files != null && files[0] != null)
                        {
                            try
                            {
                                //request.theRequest = repository.GetRequest(request.theRequest.REQUEST_ID);
                                if (requestToSave.DOCUMENTATIONS == null)
                                {
                                    requestToSave.DOCUMENTATIONS = new List<DOCUMENTATION>();
                                }

                                foreach (var file in files)
                                {
                                    if (file.ContentLength > 0 && file.ContentLength <= 20971520 && isValidFileType(file)) //&& file.FileName.Contains("pdf"))
                                    {
                                        DOCUMENTATION document = new DOCUMENTATION();
                                        string subpath = "~/App_Data/Documentation/" + requestToSave.LOCATION.LOCATION_NAME + "/" + requestToSave.REQUEST_ID + "/";
                                        //Directory.CreateDirectory(subpath);

                                        //check directory has location folder, if not create one
                                        string locationFolder = Path.Combine(Server.MapPath("~/App_Data/Documentation/"), requestToSave.LOCATION.LOCATION_NAME + "/" + requestToSave.REQUEST_ID + "/");
                                        if (!Directory.Exists(locationFolder))
                                        {
                                            Directory.CreateDirectory(locationFolder);
                                        }

                                        var fileName = Path.GetFileName(file.FileName);
                                        string filePath = Path.Combine(Server.MapPath(subpath), fileName);
                                        file.SaveAs(filePath);
                                        document.REQUEST_DOCUMENTATION_PATH = requestToSave.LOCATION.LOCATION_NAME + "/" + requestToSave.REQUEST_ID + "/" + fileName;
                                        requestToSave.DOCUMENTATIONS.Add(document);
                                        repository.SaveRequest(requestToSave);
                                    }
                                    else
                                    {
                                        ModelState.AddModelError("Error", "One or more file has an invalid file type or file size is over 20MB");
                                        SetRequestViewModelProperties(request);
                                        request.isEdit = request.isEdit;
                                        return View(request);
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                ModelState.AddModelError("Error", "An error occured while saving the uploaded file");
                                repository.SendExceptionMail(ex, System.Web.HttpContext.Current.Request);

                                SetRequestViewModelProperties(request);
                                request.isEdit = request.isEdit;
                                if (request.isEdit)
                                {
                                    request.isReadOnly = false;
                                }
                                else
                                {
                                    if (requestToSave.REQUEST_ID == 0)
                                    {
                                        request.isReadOnly = false;
                                    }
                                    else
                                    {
                                        request.isReadOnly = true;
                                    }
                                }
                                request.canUploadFile = true;

                                //request.userRoles = userUser.LOCATION_PERMISSIONS.Select(s => s.USER_PERMISSION).ToList();

                                if (Session["ActionRequired"] == null)
                                {
                                    GetApprovalReviewRequests(request);
                                    Session["ActionRequired"] = request.reviewList.Count();
                                    Session["ApprovalRequired"] = request.approvalList.Count();
                                }

                                ViewBag.ActionRequired = Convert.ToInt16(Session["ActionRequired"].ToString());
                                ViewBag.ApprovalRequired = Convert.ToInt16(Session["ApprovalRequired"]);
                                return View(request);
                            }
                        }

                        requestToSave.NARRATIVE.FUNDING_NARRATIVE = request.theRequest.NARRATIVE.FUNDING_NARRATIVE;
                        requestToSave.NARRATIVE.REASON_NARRATIVE = request.theRequest.NARRATIVE.REASON_NARRATIVE;
                        requestToSave.NARRATIVE.REVIEWER_NARRATIVE = request.theRequest.NARRATIVE.REVIEWER_NARRATIVE;
                        requestToSave.NARRATIVE.SPECIAL_NEED_NARRATIVE = request.theRequest.NARRATIVE.SPECIAL_NEED_NARRATIVE;
                        requestToSave.NARRATIVE.SPECIFIC_PROGRAM_AREA_NARRATIVE = request.theRequest.NARRATIVE.SPECIFIC_PROGRAM_AREA_NARRATIVE;
                        requestToSave.NARRATIVE.STAFFING_NARRATIVE = request.theRequest.NARRATIVE.STAFFING_NARRATIVE;

                        repository.SaveNarrative(requestToSave.NARRATIVE);
*/
                        return RedirectToAction("ViewConsideration", new { id = consid.theProgramConsideration.PROGRAM_CONSIDERATION_ID });
                    }
                    catch (Exception ex)
                    {
                        repository.SendExceptionMail(ex, System.Web.HttpContext.Current.Request);
                        SetConsidViewModelProperties(consid);
                        consid.isEdit = consid.isEdit;
                        if (consid.isEdit)
                        {
                            consid.isReadOnly = false;
                        }
                        else
                        {
                            if (requestToSave.PROGRAM_CONSIDERATION_ID == 0)
                            {
                                consid.isReadOnly = false;
                            }
                            else
                            {
                                consid.isReadOnly = true;
                            }
                        }
                        consid.canUploadFile = true;
                        /* TODO - workflow
                        if (Session["ActionRequired"] == null)
                        {
                            GetApprovalReviewRequests(request);
                            Session["ActionRequired"] = request.reviewList.Count();
                            Session["ApprovalRequired"] = request.approvalList.Count();
                        }

                        ViewBag.ActionRequired = Convert.ToInt16(Session["ActionRequired"].ToString());
                        ViewBag.ApprovalRequired = Convert.ToInt16(Session["ApprovalRequired"]);
                        */
                        return View(consid);
                    }

                case "DO NOT CREATE REQUEST":
                    return RedirectToAction("Index");
                case "CANCEL":
                default:
                    if (consid.theProgramConsideration.PROGRAM_CONSIDERATION_ID != 0)
                    {
                        return RedirectToAction("ViewConsideration", new { id = consid.theProgramConsideration.PROGRAM_CONSIDERATION_ID });
                    }
                    else
                    {
                        return RedirectToAction("Index");
                    }
            }
        }

        protected List<STAKEHOLDER_GROUP> ProcessAffectedStakeholderCheckBoxes(List<AFFECTED_STAKEHOLDER> requestTypeList, List<int> RequestTypesSelected = null)
        {
            List<STAKEHOLDER_GROUP> tempList = new List<STAKEHOLDER_GROUP>();

            if (RequestTypesSelected != null)
            {
                foreach (var requestTypeSelected in RequestTypesSelected)
                {
                    STAKEHOLDER_GROUP requestType = new STAKEHOLDER_GROUP();
                    requestType = repository.STAKEHOLDER_GROUPS.Where(w => w.STAKEHOLDER_GROUP_ID == requestTypeSelected).FirstOrDefault();
                    tempList.Add(requestType);
                }
            }

            if (requestTypeList.Count > 0)
            {
                var requestTypesToRemove = requestTypeList.Except(tempList).ToList();
                var requestTypesToAdd = tempList.Except(requestTypeList).ToList();
                foreach (var requestTypes in requestTypesToAdd)
                {
                    requestTypeList.Add(requestTypes);
                }

                foreach (var requestTypes in requestTypesToRemove)
                {
                    requestTypeList.Remove(requestTypes);
                }
            }
            else
            {
                requestTypeList = tempList;
            }

            return requestTypeList;
        }


    }
}
