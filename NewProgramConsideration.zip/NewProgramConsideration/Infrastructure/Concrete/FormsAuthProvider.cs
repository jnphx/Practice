﻿using NewProgramConsideration.Infrastructure.Abstract;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;
using System.Linq;
using System.Web;
using System.Web.Security;


namespace NewProgramConsideration.Infrastructure.Concrete
{
    public class FormsAuthProvider : IAuthProvider
    {
        public bool Authenticate(string username, string password)
        {
            //            bool result = IsValidADUser(username, password);
            bool result = AuthenticateAD(username, password);

            if (result)
            {
                FormsAuthentication.SetAuthCookie(username, false);
                HttpContext.Current.Session[Constants.SESSION_VARIABLE_CURRENT_USER_NAME] = username;
            }

            return result;
        }

        private bool AuthenticateAD(string username, string password)
        {
            bool authentic = false;
            string LDAP_SERVER_NAME = ConfigurationManager.AppSettings[Constants.APP_SETTINGS_LDAP_SERVER_NAME];

            try
            {
                using (DirectoryEntry entry = new DirectoryEntry(LDAP_SERVER_NAME, username, password, AuthenticationTypes.Secure))
                {
                    //Bind to the native AdsObject to force authentication.
                    object nativeObject = entry.NativeObject;
                    authentic = true;
                    //    //ErrorEmailer.WriteToEventLog(String.Format("Login Successful for username {0} at {1}", username, DateTime.Now), System.Diagnostics.EventLogEntryType.Information);
                }
            }
            catch (Exception FailedLoginEx) //if we caught this the native Object bind failed (not authentic)
            {
                //ErrorEmailer.EmailErrorMessage(FailedLoginEx.ToString());
                //ErrorEmailer.WriteToEventLog(String.Format("Login failed for username {0} at {1}", username, DateTime.Now), System.Diagnostics.EventLogEntryType.Warning);
            }

            return authentic;
        }

        // This is a different authentication mechanism.  I don't need it, so I'll just
        // comment it out in case we need a more thorough mechanism at a later date.

        #region IsValidADUser
        /*
        private bool IsValidADUser(string username, string password)
        {
            bool isValidUser = false;
            try
            {
                using (DirectoryEntry directoryEntry = new DirectoryEntry(Constants.LDAP_SERVER_NAME, "admin", "password", AuthenticationTypes.Secure))
                {
                    if (!string.IsNullOrEmpty(Constants.LDAP_SERVER_NAME))
                    {
                        directoryEntry.Path = Constants.LDAP_SERVER_NAME;
                        directoryEntry.Username = username;
                        directoryEntry.Password = password;
                        directoryEntry.AuthenticationType = AuthenticationTypes.Secure;
                    }
                    else
                    {
                        throw new Exception(Constants.ERROR_MESSAGE_BAD_LDAP_NAME);
                    }
                    if (directoryEntry.NativeObject != null)
                    {
                        // Verify the user is locked or not
                        DirectorySearcher searcher = new DirectorySearcher(directoryEntry);
                        searcher.Filter = "(SAMAccountName=" + username + ")";
                        searcher.CacheResults = false;
                        SearchResult result = searcher.FindOne();

                        if (result == null || result.Properties["lockoutTime"][0].ToString() != "0")
                        {
                            //                    throw new Exception(ErrorConstants.AD_ACC_LOCKED_ERR);
                        }
                        else
                        {
                            isValidUser = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorEmailer.ErrorNotification.EmailErrorMessage(ex.ToString());
            }
            return isValidUser;
        }
*/
        #endregion
    }
}