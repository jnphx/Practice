﻿using NewProgramConsideration.Infrastructure.Abstract;
using NewProgramConsideration.Models;
using NewProgramConsideration.ViewModels;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Web;
using WESD.ErrorEmailer;

namespace NewProgramConsideration.Infrastructure.Concrete
{
    public class NewProgRepository : IRepository
    {
        private DataContext context = new DataContext();


        public IQueryable<APP_USER> APP_USERS { get { return context.APP_USERS; } }
        public IQueryable<ERROR_LOG> ERROR_LOGS { get { return context.ERROR_LOGS; } }
        public IQueryable<LOCATION> LOCATIONS { get { return context.LOCATIONS; } }
        public IQueryable<STAKEHOLDER_GROUP> STAKEHOLDER_GROUPS { get { return context.STAKEHOLDER_GROUPS; } }
        public IQueryable<AFFECTED_STAKEHOLDER> AFFECTED_STAKEHOLDERS { get { return context.AFFECTED_STAKEHOLDERS; } }
        public IQueryable<LOCATION_USER_ROLE> LOCATION_USER_ROLES { get { return context.LOCATION_USER_ROLES; } }
        public IQueryable<USER_ROLE> USER_ROLES { get { return context.USER_ROLES; } }


        //Repository Methods
        public void SendExceptionMail(Exception ex, HttpRequest Request)
        {
            ErrorEmailer exceptionMailer = new ErrorEmailer(ex, Request);
            exceptionMailer.ProjectName = Constants.APP_SETTINGS_APPLICATION_NAME_LONG;
            exceptionMailer.Recipients.Add(Constants.APP_SETTINGS_MIS_ERROR_EMAIL);
            exceptionMailer.SendEmailMessage();
        }

        public void SendEmailMessage(List<APP_USER> EmailRecipients, string subject, string emailBody, string url)
        {
            if (EmailRecipients.Count() > 0)
            {
                MailMessage message = new MailMessage();
                SmtpClient smtpClient = new SmtpClient(Constants.APP_SETTINGS_EMAIL_SERVER);

                message.From = new MailAddress("donotreply@wesdschools.org", "WESD " + CONSTANTS.WEB_APP_NAME + " Notifier");
                message.Subject = subject;
                message.Priority = MailPriority.High;

                //Add any recipients here
                foreach (var user in EmailRecipients)
                {
                    try
                    {
                        MailAddress address = new MailAddress(GetEmailAddress(user.APP_USER_NAME));
                        message.To.Add(address);
                    }
                    catch
                    {
                        MailMessage errromessage = new MailMessage();

                        errromessage.From = new MailAddress("donotreply@wesdschools.org", "WESD Error Message Notifier");
                        errromessage.Subject = CONSTANTS.WEB_APP_NAME + " - Invalid Email Address";
                        errromessage.Priority = MailPriority.High;
                        errromessage.Body = "An Error has occurred in the " + CONSTANTS.WEB_APP_NAME + " application.  The email address for " + user.FullName + " (" + user.APP_USER_NAME + ") is invalid.";
                        MailAddress errorAddress = new MailAddress("MISWebDev@wesdschools.org");
                        errromessage.To.Add(errorAddress);
                        smtpClient.Send(errromessage);
                    }
                }

                //message.To.Add("steve.chov@wesdschools.org");  //testing purposes

                message.Body = emailBody + "\n\n" + url;

                smtpClient.Send(message);
            }
        }

        public void SendEmailMessageHtml(List<string> emailRecipients, string subject, string emailBody, string url)
        {
            MailMessage message = new MailMessage();
            SmtpClient smtpClient = new SmtpClient(Constants.APP_SETTINGS_EMAIL_SERVER);

            message.From = new MailAddress("donotreply@wesdschools.org", "WESD Employee Directory Application Notifier");
#if DEBUG
            message.Subject = "***TEST*** " + Constants.APP_SETTINGS_APPLICATION_NAME_LONG + " - " + subject;
            message.Body = "***TEST*** " + emailBody;
#else
            message.Subject = Constants.APP_SETTINGS_APPLICATION_NAME_LONG + " - " + subject;
            message.Body = emailBody;
#endif
            message.Priority = MailPriority.High;

            //Add any recipients here
            foreach (var user in emailRecipients)
            {
                MailAddress address = new MailAddress(user);
                message.To.Add(address);
            }

            //message.To.Add("steve.chov@wesdschools.org");  //testing purposes

            message.Body = emailBody + "\n\n" + url;
            message.IsBodyHtml = true;

            if (emailRecipients.Count() > 0)
            {
                try
                {
                    smtpClient.Send(message);
                }
                catch (Exception ex)
                {
                    SendExceptionMail(ex, System.Web.HttpContext.Current.Request);
                }
            }
        }

        //Program Considerations
        public PROGRAM_CONSIDERATION GetProgramConsideration(int id)
        {
            return context.PROGRAM_CONSIDERATIONS.Find(id);
        }

        public void SaveProgramConsideration(PROGRAM_CONSIDERATION considToSave)
        {
            if (considToSave.PROGRAM_CONSIDERATION_ID == 0)
            {
                context.PROGRAM_CONSIDERATIONS.Add(considToSave);
                context.BUDGETS.Add(considToSave.BUDGET);
                context.PROGRAMS.Add(considToSave.PROGRAM);
            }
            else
            {
                PROGRAM_CONSIDERATION progConsideration = context.PROGRAM_CONSIDERATIONS.Find(considToSave.PROGRAM_CONSIDERATION_ID);
                if (progConsideration != null)
                {
                    progConsideration.SCHOOL_DEPT_REQUESTOR = considToSave.SCHOOL_DEPT_REQUESTOR;
                    progConsideration.NEED_EXPLANATION = considToSave.NEED_EXPLANATION;
                    progConsideration.AFFECTED_STAKEHOLDERS = considToSave.AFFECTED_STAKEHOLDERS;
                    //TODO - add fields
                    //Add fields for Budget and Program
                    BUDGET budget = context.BUDGETS
                                    .Where(b => b.PROGRAM_CONSIDERATION_ID == considToSave.PROGRAM_CONSIDERATION_ID)
                                    .FirstOrDefault();
                    budget.START_UP_COSTS = considToSave.BUDGET.START_UP_COSTS;
                    budget.START_UP_DETAILS = considToSave.BUDGET.START_UP_DETAILS;
                    budget.IMPLEMENTATIONS_COSTS = considToSave.BUDGET.IMPLEMENTATIONS_COSTS;
                    PROGRAM program = context.PROGRAMS
                                    .Where(b => b.PROGRAM_CONSIDERATION_ID == considToSave.PROGRAM_CONSIDERATION_ID)
                                    .FirstOrDefault();
                    program.CONTACT = considToSave.PROGRAM.CONTACT;
                    program.LOCATION_ID = considToSave.PROGRAM.LOCATION_ID;
                    program.EMAIL = considToSave.PROGRAM.EMAIL;
                    program.PROGRAM_NAME = considToSave.PROGRAM.PROGRAM_NAME;
                    program.NUM_STAFF = considToSave.PROGRAM.NUM_STAFF;
                    program.NUM_STUDENTS = considToSave.PROGRAM.NUM_STUDENTS;
                }
            }
            try
            {
                context.SaveChanges();
            } catch (Exception e)
            {
                SendErrorToTextFile("SaveProgramConsideration context.SaveChanges()", e);
            }
        }

        public LOCATION GetLocation(int id)
        {
            return context.LOCATIONS.Find(id);
        }

        public void SaveLocation(LOCATION locationToSave)
        {
            if (locationToSave.LOCATION_ID == 0)
            {
                context.LOCATIONS.Add(locationToSave);
            }
            else
            {
                LOCATION location = context.LOCATIONS.Find(locationToSave.LOCATION_ID);
                if (location != null)
                {
                    location.LOCATION_CODE = locationToSave.LOCATION_CODE;
                    location.LOCATION_NAME = locationToSave.LOCATION_NAME;
                }
            }
            context.SaveChanges();
        }


        //Get User
        public IEnumerable<APP_USER> GetUsers()
        {
            return context.APP_USERS.ToList();
        }

        //Save User
        public void SaveUser(APP_USER userToSave)
        {
            if (userToSave.APP_USER_ID == 0)
            {
                context.APP_USERS.Add(userToSave);
            }
            else
            {
                APP_USER user = context.APP_USERS.Find(userToSave.APP_USER_ID);
                if (user != null)
                {
                    user.EMAIL = userToSave.EMAIL;
                    user.APP_USER_NAME = userToSave.APP_USER_NAME;
                    user.FIRST_NAME = userToSave.FIRST_NAME;
                    user.IS_ACTIVE = userToSave.IS_ACTIVE;
                    user.LAST_NAME = userToSave.LAST_NAME;
                }
            }
            context.SaveChanges();
        }

        //Find User by Id
        public APP_USER GetUserByID(int id)
        {
            return context.APP_USERS.Find(id);
        }

        public APP_USER GetUserByUserName(string userName)
        {
            var user = context.APP_USERS.Where(w => w.APP_USER_NAME == userName).FirstOrDefault();
            return user;
        }

        public USER_ROLE GetUserRole(int userRoleId)
        {
            return context.USER_ROLES.Find(userRoleId);
        }

        public void SaveUserRole(USER_ROLE userRoleToSave)
        {
            if (userRoleToSave.USER_ROLE_ID == 0)
            {
                context.USER_ROLES.Add(userRoleToSave);
            }
            else
            {
                USER_ROLE user = context.USER_ROLES.Find(userRoleToSave.USER_ROLE_ID);
                if (user != null)
                {
                    user.NAME = userRoleToSave.NAME;
                    user.DESCRIPTION = userRoleToSave.DESCRIPTION;
                }
            }
            context.SaveChanges();
        }

        public string GetEmailAddress(string userName)
        {
            var name = userName.ToLower();
            if (userName == "appuser" || userName == "appadmin")
            {
                return CONSTANTS.DEVELOPER_EMAIL;
            }
            else
            {
                return GetUserAdObject(userName).Properties["mail"][0].ToString();
            }
        }

        public string GetUserFirstName(string userName)
        {
            return GetUserAdObject(userName).Properties["givenName"][0].ToString();
        }

        public string GetUserLastName(string userName)
        {
            return GetUserAdObject(userName).Properties["sn"][0].ToString();
        }

        public string GetUserFullName(string userName)
        {
            return GetUserAdObject(userName).Properties["givenName"][0].ToString() + " " + GetUserAdObject(userName).Properties["sn"][0].ToString();
        }

        public string GetUserFullNameAndUserName(string userName)
        {
            return GetUserAdObject(userName).Properties["givenName"][0].ToString() + " " + GetUserAdObject(userName).Properties["sn"][0].ToString() + " (" + userName + ")";
        }

        public SearchResult GetUserAdObject(string userName)
        {
            string LDAP_SERVER_NAME = ConfigurationManager.AppSettings[Constants.APP_SETTINGS_LDAP_SERVER_NAME];
            DirectoryEntry entry = new DirectoryEntry(LDAP_SERVER_NAME);

            // get a DirectorySearcher object
            DirectorySearcher search = new DirectorySearcher(entry);

            // specify the search filter
            search.Filter = "(&(objectClass=user)(anr=" + userName + "))";

            // specify which property values to return in the search
            search.PropertiesToLoad.Add("givenName");   // first name
            search.PropertiesToLoad.Add("sn");          // last name
            search.PropertiesToLoad.Add("mail");        // smtp mail address    
            search.PropertiesToLoad.Add("telephoneNumber");

            // perform the search
            SearchResult result = search.FindOne();
            return result;
        }

        public SearchResultCollection GetUserAdObjectAll(string userName)
        {
            string LDAP_SERVER_NAME = ConfigurationManager.AppSettings[Constants.APP_SETTINGS_LDAP_SERVER_NAME];
            DirectoryEntry entry = new DirectoryEntry(LDAP_SERVER_NAME);

            // get a DirectorySearcher object
            DirectorySearcher search = new DirectorySearcher(entry);

            // specify the search filter
            search.Filter = "(&(objectClass=user)(anr=" + userName + "))";

            // specify which property values to return in the search
            search.PropertiesToLoad.Add("givenName");   // first name
            search.PropertiesToLoad.Add("sn");          // last name
            search.PropertiesToLoad.Add("mail");        // smtp mail address    
            search.PropertiesToLoad.Add("telephoneNumber");
            search.PropertiesToLoad.Add("samaccountname");

            // perform the search
            var result = search.FindAll();
            return result;
        }

        public SearchResult GetUserAdObjectByEmployeeNumber(string empNumber)
        {
            string LDAP_SERVER_NAME = ConfigurationManager.AppSettings[Constants.APP_SETTINGS_LDAP_SERVER_NAME];
            DirectoryEntry entry = new DirectoryEntry(LDAP_SERVER_NAME);

            // get a DirectorySearcher object
            DirectorySearcher search = new DirectorySearcher(entry);

            // specify the search filter
            search.Filter = "(&(objectClass=user)(employeeID=" + empNumber + "))";

            // specify which property values to return in the search
            search.PropertiesToLoad.Add("givenName");   // first name
            search.PropertiesToLoad.Add("sn");          // last name
            search.PropertiesToLoad.Add("mail");        // smtp mail address    
            search.PropertiesToLoad.Add("telephoneNumber");
            search.PropertiesToLoad.Add("employeeID");
            search.PropertiesToLoad.Add("samaccountname");

            // perform the search
            SearchResult result = search.FindOne();
            return result;
        }
        public List<APP_USER> GetUsersByLocation(int locationId)
        {
            List<APP_USER> userList = new List<APP_USER>();
            return userList = context.APP_USERS.Where(w => w.LOCATION_USER_ROLES.Any(a => a.LOCATION_ID == locationId)).ToList();
        }

        public List<LOCATION_USER_ROLE> GetUserLocationUserRoles(int userId)
        {
            List<LOCATION_USER_ROLE> locationList = new List<LOCATION_USER_ROLE>();
            locationList = context.LOCATION_USER_ROLES.Where(w => w.APP_USER_ID == userId).ToList();
            return locationList;
        }

        public LOCATION_USER_ROLE GetLocationUserRole(int locationUserRoleId)
        {
            return context.LOCATION_USER_ROLES.Find(locationUserRoleId);
        }

        public void SaveLocationUserRole(LOCATION_USER_ROLE locationUserRoleToSave)
        {
            if (locationUserRoleToSave.LOCATION_USER_ROLE_ID == 0)
            {
                context.LOCATION_USER_ROLES.Add(locationUserRoleToSave);
            }
            else
            {
                LOCATION_USER_ROLE location = context.LOCATION_USER_ROLES.Find(locationUserRoleToSave.LOCATION_USER_ROLE_ID);
                if (location != null)
                {
                    location.APP_USER_ID = locationUserRoleToSave.APP_USER_ID;
                    location.LOCATION_ID = locationUserRoleToSave.LOCATION_ID;
                    location.USER_ROLE_ID = locationUserRoleToSave.USER_ROLE_ID;
                }
            }
            context.SaveChanges();
        }

        public void RemoveLocationUserRole(int locationUserRoleId)
        {
            LOCATION_USER_ROLE locationUserRole = context.LOCATION_USER_ROLES.Find(locationUserRoleId);
            context.LOCATION_USER_ROLES.Remove(locationUserRole);
            context.SaveChanges();
        }

        public ERROR_LOG GetErrorLog(int errorLogId)
        {
            return context.ERROR_LOGS.Find(errorLogId);
        }

        public void SaveErrorLog(ERROR_LOG errorLogToSave)
        {
            if (errorLogToSave.ERROR_LOG_ID == 0)
            {
                context.ERROR_LOGS.Add(errorLogToSave);
            }
            else
            {
                ERROR_LOG error = context.ERROR_LOGS.Find(errorLogToSave.ERROR_LOG_ID);
                if (error != null)
                {
                    error.ACTION = errorLogToSave.ACTION;
                    error.APP_USER_ID = errorLogToSave.APP_USER_ID;
                    error.CONTROLLER = errorLogToSave.CONTROLLER;
                    error.DATA = errorLogToSave.DATA;
                    error.HRESULT = errorLogToSave.HRESULT;
                    error.INNER_EXCEPTION = errorLogToSave.INNER_EXCEPTION;
                    error.MESSAGE = errorLogToSave.MESSAGE;
                    error.SOURCE = errorLogToSave.SOURCE;
                    error.STACK_TRACE = errorLogToSave.STACK_TRACE;
                    error.BROWSER = errorLogToSave.BROWSER;
                }
            }
            context.SaveChanges();
        }

        public void SaveErrorLog(string controller, string action, int? userId, Exception ex)
        {
            ERROR_LOG error = new ERROR_LOG();
            error.ACTION = action;
            error.APP_USER_ID = userId;
            error.CONTROLLER = controller;
            error.DATA = ex.Data.ToString();
            error.HRESULT = ex.HResult.ToString();
            if (ex.InnerException != null)
            {
                error.INNER_EXCEPTION = ex.InnerException.ToString();
            }
            error.MESSAGE = ex.Message.ToString();
            error.SOURCE = ex.Source.ToString();
            error.STACK_TRACE = ex.StackTrace.ToString();
            error.BROWSER = GetBrowserDetails();
        }

        public static string GetBrowserDetails()
        {
            string browserDetails = string.Empty;
            System.Web.HttpBrowserCapabilities browser = HttpContext.Current.Request.Browser;
            browserDetails =
            "Name = " + browser.Browser + "," +
            "Type = " + browser.Type + ","
            + "Version = " + browser.Version + ","
            + "Major Version = " + browser.MajorVersion + ","
            + "Minor Version = " + browser.MinorVersion + ","
            + "Platform = " + browser.Platform + ","
            + "Is Beta = " + browser.Beta + ","
            + "Is Crawler = " + browser.Crawler + ","
            + "Is AOL = " + browser.AOL + ","
            + "Is Win16 = " + browser.Win16 + ","
            + "Is Win32 = " + browser.Win32 + ","
            + "Supports Frames = " + browser.Frames + ","
            + "Supports Tables = " + browser.Tables + ","
            + "Supports Cookies = " + browser.Cookies + ","
            + "Supports VBScript = " + browser.VBScript + ","
            + "Supports JavaScript = " + "," +
            browser.EcmaScriptVersion.ToString() + ","
            + "Supports Java Applets = " + browser.JavaApplets + ","
            + "Supports ActiveX Controls = " + browser.ActiveXControls
            + ","
            + "Supports JavaScript Version = " +
            browser["JavaScriptVersion"];
            return browserDetails;
        }

        public void Save()
        {
            context.SaveChanges();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void SendErrorToTextFile(string msg, Exception ex = null)
        {
            var line = Environment.NewLine + Environment.NewLine;
            string filepath = System.Web.HttpContext.Current.Server.MapPath("~/ErrorLog/");  //Text File Path

            if (!Directory.Exists(filepath))
            {
                Directory.CreateDirectory(filepath);
            }

            filepath = filepath + "ErrorLogging.txt";   //Text File Name

            if (!System.IO.File.Exists(filepath))
            {
                System.IO.File.Create(filepath).Dispose();
            }

            if (ex != null)
            {
                var ErrorlineNo = ex.StackTrace.Substring(ex.StackTrace.Length - 7, 7);
                var Errormsg = ex.GetType().Name.ToString();
                var extype = ex.GetType().ToString();
                var exurl = System.Web.HttpContext.Current.Request.Url.ToString();
                var ErrorLocation = ex.Message.ToString() + " : " + ex.InnerException.ToString() ?? "";
                var hostIp = string.Empty;

                try
                {
                    using (StreamWriter sw = System.IO.File.AppendText(filepath))
                    {
                        string error = "Log Written Date:" + " " + DateTime.Now.ToString() + line + "Error Line No :" + " " + ErrorlineNo + line + "Error Message:" + " " + Errormsg + line + "Exception Type:" + " " + extype + line + "Error Location :" + " " + ErrorLocation + line + " Error Page Url:" + " " + exurl + line + "User Host IP:" + " " + hostIp + line;
                        sw.WriteLine("-----------Exception Details on " + " " + DateTime.Now.ToString() + "-----------------");
                        sw.WriteLine("-------------------------------------------------------------------------------------");
                        sw.WriteLine(error);
                        sw.WriteLine("--------------------------------*End*------------------------------------------");
                        sw.WriteLine(line);
                        sw.Flush();
                        sw.Close();
                    }

                }
                catch (Exception e)
                {
                    e.ToString();

                }
            }
            else
            {
                try
                {
                    using (StreamWriter sw = System.IO.File.AppendText(filepath))
                    {
                        string error = "Log Written Date:" + " " + DateTime.Now.ToString() + line + msg + "";
                        sw.WriteLine("-----------Exception Details on " + " " + DateTime.Now.ToString() + "-----------------");
                        sw.WriteLine("-------------------------------------------------------------------------------------");
                        sw.WriteLine(error);
                        sw.WriteLine("--------------------------------*End*------------------------------------------");
                        sw.WriteLine(line);
                        sw.Flush();
                        sw.Close();
                    }

                }
                catch (Exception e)
                {
                    e.ToString();
                }
            }
        }

        public LOCATION_USING_PROGRAM GetLocationUsingProgram(int getLocationUsingProgramId)
        {
            return context.LOCATION_USING_PROGRAMS.Find(getLocationUsingProgramId);
        }

        public void SaveLocationUsingProgram(LOCATION_USING_PROGRAM locationUsingProgramToSave)
        {
            if (locationUsingProgramToSave.LOCATION_USING_PROGRAM_ID == 0)
            {
                context.LOCATION_USING_PROGRAMS.Add(locationUsingProgramToSave);
            }
            else
            {
                LOCATION_USING_PROGRAM location = context.LOCATION_USING_PROGRAMS.Find(locationUsingProgramToSave.LOCATION_USING_PROGRAM_ID);
                if (location != null)
                {
                    location.LOCATION_ID = locationUsingProgramToSave.LOCATION_ID;
                }
            }
            context.SaveChanges();
        }

        public void RemoveLocationUsingProgram(int locationUsingProgramToSave)
        {
            LOCATION_USING_PROGRAM locationUserRole = context.LOCATION_USING_PROGRAMS.Find(locationUsingProgramToSave);
            context.LOCATION_USING_PROGRAMS.Remove(locationUserRole);
            context.SaveChanges();
        }


    }
}
