﻿using NewProgramConsideration.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;

namespace NewProgramConsideration.Infrastructure
{
    public class RolesProvider : RoleProvider
    {
        public override string[] GetRolesForUser(string username)
        {
            using (DataContext db = new DataContext())
            {
                APP_USER user = db.APP_USERS.FirstOrDefault(u => u.APP_USER_NAME.Equals(username, StringComparison.CurrentCultureIgnoreCase));

                //var roles = from r in db.USER_PERMISSIONS
                //            where user.USER_PERMISSION_LEVEL == r.USER_PERMISSION_ID
                //            select r.USER_PERMISSION_NAME;

                var roles = from r in db.LOCATION_USER_ROLES
                            where user.APP_USER_ID == r.APP_USER_ID
                            select r.USER_ROLE.NAME;
                if (user != null)
                    return roles.ToArray();
                else
                    return new string[] { };
            }
        }

        public override bool IsUserInRole(string username, string roleName)
        {
            using (DataContext db = new DataContext())
            {
                APP_USER user = db.APP_USERS.FirstOrDefault(u => u.APP_USER_NAME.Equals(username, StringComparison.CurrentCultureIgnoreCase));

                //var roles = from ur in db.APP_USERS
                //            from r in db.LOCATION_USER_ROLES
                //            where ur.USER_PERMISSION_LEVEL == r.USER_PERMISSION_ID
                //            select r.USER_PERMISSION_NAME;
                if (user != null)
                    return user.LOCATION_USER_ROLES.Any(r => r.USER_ROLE.NAME.Equals(roleName, StringComparison.CurrentCultureIgnoreCase));
                else
                    return false;
            }
        }

        #region Not Implemented Methods
        //not implemented methods
        public override void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }

        public override string ApplicationName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public override void CreateRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            throw new NotImplementedException();
        }

        public override string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            throw new NotImplementedException();
        }

        public override string[] GetAllRoles()
        {
            throw new NotImplementedException();
        }

        public override string[] GetUsersInRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }

        public override bool RoleExists(string roleName)
        {
            throw new NotImplementedException();
        }
        #endregion

    }
}