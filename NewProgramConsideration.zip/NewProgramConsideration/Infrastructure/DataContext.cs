﻿using NewProgramConsideration.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Infrastructure
{
    public class DataContext : DbContext
    {
#if DEBUG
#if RE_DEBUG
            public DataContext()
                : base("DataContext")
            {
                this.Configuration.LazyLoadingEnabled = true;
            }
#else
        public DataContext()
            : base("DataContextTest")
        {
            this.Configuration.LazyLoadingEnabled = true;
        }
#endif
#else
        public DataContext()
            : base("DataContext")
        {
            this.Configuration.LazyLoadingEnabled = true;
        }

#endif


        public DbSet<APP_USER> APP_USERS { get; set; }
        public DbSet<ERROR_LOG> ERROR_LOGS { get; set; }
        public DbSet<LOCATION> LOCATIONS { get; set; }
        public DbSet<LOCATION_USER_ROLE> LOCATION_USER_ROLES { get; set; }
        public DbSet<USER_ROLE> USER_ROLES { get; set; }
        public DbSet<PROGRAM_CONSIDERATION> PROGRAM_CONSIDERATIONS { get; set; }
        public DbSet<PROGRAM> PROGRAMS { get; set; }
        public DbSet<BUDGET> BUDGETS { get; set; }
        public DbSet<STAKEHOLDER_GROUP> STAKEHOLDER_GROUPS { get; set; }
        public DbSet<AFFECTED_STAKEHOLDER> AFFECTED_STAKEHOLDERS { get; set; }
        public DbSet<POSITION> POSITIONS { get; set; }
        public DbSet<LOCATION_USING_PROGRAM> LOCATION_USING_PROGRAMS { get; set; }

        //Workflow Models
        //public DbSet<WORKFLOW> Workflows { get; set; }
        //public DbSet<WORKFLOW_DEF> WorkflowDefs { get; set; }

        //public DbSet<WORKFLOW_APPROVER> WorkflowApprovers { get; set; }
        //public DbSet<WORKFLOW_APPROVER_DEF> WorkflowApproverDefs { get; set; }

        //public DbSet<WORKFLOW_APPROVER_IN_STEP_DEF> WorkflowApproversInStepDef { get; set; }
        //public DbSet<WORKFLOW_APPROVER_IN_STEP> WorkflowApproversInStep { get; set; }


        //public DbSet<WORKFLOW_STEP> WorkflowSteps { get; set; }
        //public DbSet<WORKFLOW_STEP_DEF> WorkflowStepDefs { get; set; }

        //public DbSet<WORKFLOW_TYPE_DATA_VALUE_CONFIG> WorkflowTypeDataValueConfigs { get; set; }
        //public DbSet<WORKFLOW_TYPE_DATA_VALUE_CONFIG_DEF> WorkflowTypeDataValueConfigDefs { get; set; }

        //public DbSet<WORKFLOW_STEP_DEF_IN_WORKFLOW_DEF> WorkflowStepDefInWorkflowDefs { get; set; }
        //public DbSet<WORKFLOW_STEP_IN_WORKFLOW> WorkflowStepInWorkflows { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            /*
            modelBuilder.Entity<PROGRAM_CONSIDERATION>()
             .HasMany(c => c.AFFECTED_STAKEHOLDERS).WithMany(i => i.PROGRAM_CONSIDERATIONS)
             .Map(t => t.MapLeftKey("PROGRAM_CONSIDERATION_ID")
                 .MapRightKey("STAKEHOLDER_GROUP_ID")
                 .ToTable("PROGRAM_CONSIDERATION_STAKEHOLDER_GROUP")); */
        }

    }
}