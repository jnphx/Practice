﻿using NewProgramConsideration.Models;
using NewProgramConsideration.ViewModels;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Web;

namespace NewProgramConsideration.Infrastructure.Abstract
{
    public interface IRepository
    {

        IQueryable<APP_USER> APP_USERS { get; }
        IQueryable<ERROR_LOG> ERROR_LOGS { get; }
        IQueryable<LOCATION> LOCATIONS { get; }
        IQueryable<STAKEHOLDER_GROUP> STAKEHOLDER_GROUPS { get; }
        IQueryable<AFFECTED_STAKEHOLDER> AFFECTED_STAKEHOLDERS { get; }
        IQueryable<LOCATION_USER_ROLE> LOCATION_USER_ROLES { get; }
        IQueryable<USER_ROLE> USER_ROLES { get; }


        void SendExceptionMail(Exception ex, HttpRequest Request);
        void SendEmailMessageHtml(List<string> emailRecipients, string subject, string emailBody, string url);
        //void SendEmailMessage(List<USER> EmailRecipients, string subject, string emailBody, string url);
        //EMAIL_MSG GetEmailMessageVerbiage(int emailMsgId);
        //string GetEmailSubjectLine(EMAIL_MSG msg, REQUEST request, string url, WORKFLOW_STEP currentStep);
        //string GetEmailBody(EMAIL_MSG msg, REQUEST request, string url, WORKFLOW_STEP currentStep);

        IEnumerable<APP_USER> GetUsers();
        void SaveUser(APP_USER userToSave);
        APP_USER GetUserByID(int id);

        USER_ROLE GetUserRole(int userRoleId);
        void SaveUserRole(USER_ROLE userRoleToSave);

        APP_USER GetUserByUserName(string userName);
        string GetEmailAddress(string userName);
        string GetUserFirstName(string userName);
        string GetUserLastName(string userName);
        string GetUserFullName(string userName);
        string GetUserFullNameAndUserName(string userName);
        SearchResult GetUserAdObject(string userName);
        SearchResultCollection GetUserAdObjectAll(string userName);
        SearchResult GetUserAdObjectByEmployeeNumber(string empNumber);

        LOCATION GetLocation(int id);
        void SaveLocation(LOCATION locationToSave);

        List<APP_USER> GetUsersByLocation(int locationId);
        List<LOCATION_USER_ROLE> GetUserLocationUserRoles(int userId);

        LOCATION_USER_ROLE GetLocationUserRole(int locationUserRoleId);
        void SaveLocationUserRole(LOCATION_USER_ROLE locationUserRoleToSave);
        void RemoveLocationUserRole(int locationUserRoleId);

        ERROR_LOG GetErrorLog(int errorLogId);
        void SaveErrorLog(ERROR_LOG errorLogToSave);
        void SaveErrorLog(string controller, string action, int? userId, Exception ex);
        void Dispose();
        void Save();

        void SendErrorToTextFile(string msg, Exception ex = null);

        PROGRAM_CONSIDERATION GetProgramConsideration(int id);

        void SaveProgramConsideration(PROGRAM_CONSIDERATION considToSave);

        LOCATION_USING_PROGRAM GetLocationUsingProgram(int getLocationUsingProgramId);
        void SaveLocationUsingProgram(LOCATION_USING_PROGRAM locationUsingProgramToSave);
        void RemoveLocationUsingProgram(int locationUsingProgramToSave);
    }
}